import gspread
import logging
import time
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from gspread_dataframe import set_with_dataframe
import requests  # HTTP 요청을 보내는 라이브러리
import pandas as pd  # 데이터 처리 및 엑셀 파일 저장을 위한 라이브러리
import numpy as np
import re
import var
from oauth2client.service_account import ServiceAccountCredentials
from gspread.exceptions import APIError
import traceback
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
import pyautogui
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from random_user_agent.user_agent import UserAgent
from random_user_agent.params import SoftwareName, OperatingSystem
import json
from supabase import create_client, Client

# OAuth 2.0 인증 파일 경로 설정 (구글드라이브 관련)
scopes = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive'
]
credentials = Credentials.from_service_account_file(f'{var.json_site}', scopes=scopes)

# Google Sheets 및 Drive API 초기화
gc = gspread.authorize(credentials)
drive_service = build('drive', 'v3', credentials=credentials)

# Google API 인증 설정
google_scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
google_creds = ServiceAccountCredentials.from_json_keyfile_name(var.json_site, google_scope)
google_client = gspread.authorize(google_creds)


# 구글 드라이브 폴더 내 파일 검색 함수
def get_spreadsheet_id_by_name(folder_id, file_name):
    query = f"'{folder_id}' in parents and name = '{file_name}' and mimeType = 'application/vnd.google-apps.spreadsheet'"
    results = drive_service.files().list(q=query, fields="files(id, name)").execute()
    items = results.get('files', [])

    if not items:
        return None
    else:
        return items[0]['id']
    
def create_spreadsheet_with_retry(gc, filename, retries=3, delay=5):
    """
    스프레드시트를 생성하고, 실패 시 재시도합니다.

    Parameters:
        gc (gspread.Client): gspread 클라이언트 객체
        filename (str): 생성할 스프레드시트 이름
        retries (int): 재시도 횟수 (기본값: 3)
        delay (int): 재시도 간 지연 시간 (초, 기본값: 5)

    Returns:
        gspread.Spreadsheet: 생성된 스프레드시트 객체
    """
    for attempt in range(retries):
        try:
            # 스프레드시트 생성
            spreadsheet = gc.create(filename)
            
            # 생성된 스프레드시트의 첫 번째 워크시트 이름 변경
            worksheet = spreadsheet.get_worksheet(0)
            worksheet.update_title("기본시트")
            
            return spreadsheet
        except gspread.exceptions.APIError as e:
            print(f"스프레드시트 생성 실패 (재시도 {attempt+1}/{retries}): {e}")
            time.sleep(delay)
    raise Exception(f"{filename} 스프레드시트 생성에 반복적으로 실패했습니다.")

def save_dataframe_to_sheet(spreadsheet_id, df, sheet_name):
    """
    데이터프레임을 지정한 Google 스프레드시트의 특정 워크시트에 저장하는 함수.
    기존 데이터는 삭제 후 새로운 데이터를 저장함.
    오류 발생 시 최대 3번까지 재시도함.

    Parameters:
        spreadsheet_id (str): Google 스프레드시트의 ID
        df (DataFrame): 저장할 pandas 데이터프레임
        sheet_name (str): 수정할 워크시트의 이름
    """
    # 스프레드시트 열기
    spreadsheet = gc.open_by_key(spreadsheet_id)

    # 지정된 워크시트 선택 (이름으로)
    try:
        worksheet = spreadsheet.worksheet(sheet_name)
    except Exception as e:
        raise ValueError(f"'{sheet_name}' 워크시트를 찾을 수 없습니다. 스프레드시트를 확인하세요. 에러: {e}")

    # 최대 재시도 횟수
    MAX_RETRIES = 3
    retry_delay = 5  # 재시도 간 대기 시간 (초)

    # 재시도 로직
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            # 기존 데이터를 삭제 (워크시트 초기화)
            worksheet.clear()

            # 데이터프레임을 지정한 워크시트에 저장
            set_with_dataframe(worksheet, df)
            print(f"'{spreadsheet.title}'의 '{sheet_name}' 시트에 성공적으로 저장되었습니다.")
            break
        except APIError as e:
            print(f"API 호출 중 오류 발생: {e}. {attempt}/{MAX_RETRIES}번째 시도 실패.")
            if attempt < MAX_RETRIES:
                print(f"{retry_delay}초 후 재시도합니다...")
                time.sleep(retry_delay)
            else:
                print("최대 재시도 횟수에 도달했습니다. 데이터 저장 실패.")
                raise

# def create_backup_spreadsheet(filename):
#     # 기존에 동일한 이름의 스프레드시트가 있으면 삭제
#     drive_service = build('drive', 'v3', credentials=google_creds)
#     response = drive_service.files().list(q=f"name='{filename}' and mimeType='application/vnd.google-apps.spreadsheet'").execute()
#     files = response.get('files', [])
#     for file in files:
#         drive_service.files().delete(fileId=file['id']).execute()
#         print(f"기존 스프레드시트 '{filename}'가 삭제되었습니다.")

#     spreadsheet_id = get_spreadsheet_id_by_name(var.drive_data_folder_id, filename)
#     spreadsheet = create_spreadsheet_with_retry(gc, filename)
#     spreadsheet_id = spreadsheet.id
    
#     # 기본 워크시트 이름 설정 (Sheet1 대신 사용자가 원하는 이름으로 생성)
#     try:
#         worksheet = spreadsheet.get_worksheet(0)
#         worksheet.update_title('기본시트')  # 워크시트 이름을 명시적으로 변경
#     except Exception as e:
#         print(f"워크시트 이름 변경 중 에러 발생: {e}")

#     # Google 드라이브 특정 폴더에 스프레드시트를 이동시키기
#     drive_service.files().update(
#         fileId=spreadsheet_id,
#         addParents=var.drive_data_folder_id,
#         fields='id, parents'
#     ).execute()
#     print(f"'{filename}' 스프레드시트가 생성되어 폴더로 이동되었습니다.")
    
#     return spreadsheet

def create_backup_spreadsheet(filename, max_retries=2, delay=2):
    def execute_with_retries(func, *args, **kwargs):
        """
        Executes a function with retry logic.
        """
        attempt = 0
        while attempt < max_retries:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                attempt += 1
                if attempt < max_retries:
                    print(f"Attempt {attempt} failed. Retrying in {delay} seconds...")
                    time.sleep(delay)
                else:
                    print(f"Operation failed after {max_retries} attempts.")
                    raise e

    # Google Drive API service initialization
    drive_service = build('drive', 'v3', credentials=google_creds)

    # Step 1: Check for existing spreadsheets with the same name and delete them
    def delete_existing_files():
        response = drive_service.files().list(
            q=f"name='{filename}' and mimeType='application/vnd.google-apps.spreadsheet'"
        ).execute()
        files = response.get('files', [])
        for file in files:
            drive_service.files().delete(fileId=file['id']).execute()
            print(f"Existing spreadsheet '{filename}' deleted.")

    execute_with_retries(delete_existing_files)

    # Step 2: Create a new spreadsheet
    def create_spreadsheet():
        spreadsheet = create_spreadsheet_with_retry(gc, filename)  # Assuming this is an existing function
        return spreadsheet

    spreadsheet = execute_with_retries(create_spreadsheet)
    spreadsheet_id = spreadsheet.id

    # Step 3: Rename the default worksheet
    def rename_worksheet():
        worksheet = spreadsheet.get_worksheet(0)
        worksheet.update_title('기본시트')  # Update worksheet title
        print("Worksheet renamed to '기본시트'.")

    execute_with_retries(rename_worksheet)

    # Step 4: Move the spreadsheet to the specific folder
    def move_to_folder():
        drive_service.files().update(
            fileId=spreadsheet_id,
            addParents=var.drive_data_folder_id,
            fields='id, parents'
        ).execute()
        print(f"Spreadsheet '{filename}' moved to folder.")

    execute_with_retries(move_to_folder)

    print(f"'{filename}' spreadsheet created and moved successfully.")
    return spreadsheet
    
def get_lat_lng(address, api_key, retries=3):
    """
    카카오 로컬 API를 사용하여 주소를 위도, 경도로 변환하는 함수

    :param address: 변환할 지번 주소 (예: "서울특별시 강남구 테헤란로 427")
    :param api_key: 카카오 REST API 키
    :param retries: 최대 재시도 횟수 (기본값: 3)
    :return: (위도, 경도) 튜플 반환, 변환 실패 시 (0.0, 0.0) 반환
    """

    url = "https://dapi.kakao.com/v2/local/search/address.json"
    headers = {"Authorization": f"KakaoAK {api_key}"}
    params = {"query": address}

    for attempt in range(retries):
        try:
            response = requests.get(url, headers=headers, params=params)
            status_code = response.status_code

            if status_code == 200:
                result = response.json()
                documents = result.get("documents", [])

                if documents:
                    lat = float(documents[0]["y"])  # 위도
                    lng = float(documents[0]["x"])  # 경도
                    return lat, lng
                else:
                    print(f"⚠️ 주소 변환 실패 (결과 없음): '{address}'")
                    return 0.0, 0.0  # 기본값 반환

            elif status_code == 401:
                print(f"❌ API 요청 오류 (401 Unauthorized): API 키를 확인하세요.")
                return 0.0, 0.0

            elif status_code == 429:
                print(f"⚠️ 요청 제한 초과 (429 Too Many Requests): {attempt + 1}/{retries}회 재시도 중...")
                time.sleep(2)  # 2초 대기 후 재시도

            else:
                print(f"❌ API 요청 실패 (HTTP {status_code}): {response.text}")
                return 0.0, 0.0

        except requests.exceptions.RequestException as e:
            print(f"❌ API 요청 오류: {e}")
            time.sleep(2)  # 2초 대기 후 재시도

    print(f"❌ 모든 재시도 실패: '{address}'")
    return 0.0, 0.0

# 엑셀을 데이터프레임으로 불러오는 함수. 엑셀 로드
def load_excel_to_dataframe(filepath):
    """
    엑셀 파일을 읽어 DataFrame으로 반환하는 함수

    Parameters:
        filepath (str): 읽을 엑셀 파일 경로

    Returns:
        pd.DataFrame: 불러온 데이터프레임
    """
    try:
        df = pd.read_excel(filepath)
        print(f"✅ 엑셀 파일 로딩 성공: {filepath}")
        return df
    except Exception as e:
        print(f"❌ 엑셀 파일 로딩 실패: {e}")
        return pd.DataFrame()  # 실패 시 빈 데이터프레임 반환
    

def safe_get_lat_lng(addr):
    """주소를 위도, 경도로 변환하며 예외 발생 시 (0.0, 0.0) 반환"""
    if pd.isna(addr) or addr.strip() == "":
        return pd.Series([0.0, 0.0])  # 📌 항상 Series 반환 (길이 불일치 방지)
    
    result = get_lat_lng(addr, var.kakao_api_key)
    
    if isinstance(result, tuple) and len(result) == 2:
        return pd.Series(result)  # 📌 (위도, 경도) 튜플 반환
    else:
        return pd.Series([0.0, 0.0])  # 📌 변환 실패 시 (0.0, 0.0) 반환

# 날짜 형식으로 변환하기 전에 NaN 값을 처리하고 문자열로 변환
def convert_to_date(x):
    if pd.isna(x):
        return np.nan  # NaN은 그대로 유지
    x = str(int(x))  # float 형태를 문자열로 변환
    return pd.to_datetime(f"{x[:4]}-{x[4:6]}-{x[6:]}", format='%Y-%m-%d')

# 백억매물번호 추출 함수
def extract_baikuk_number(text):
    if isinstance(text, str):  # 문자열인 경우에만 검색 수행
        # '백억 매물 번호'처럼 공백이 불규칙한 패턴도 처리
        pattern = r"백억\s*매물\s*번호\s*[:：]?\s*(\d+)"
        match = re.search(pattern, text)
        if match:
            return match.group(1)  # 매물번호 추출
    return "매물번호 오표기"

# 보증금 문자열을 숫자로 변환하는 함수 정의
def convert_deposit(description):
    if not isinstance(description, str):
        return np.nan  # NaN 처리

    # 정규표현식을 통해 보증금과 "/" 또는 "월세" 또는 "임대료" 사이의 텍스트 추출
    match = re.search(r"보증금\s*([^/월세임대료]+)", description)
    if not match:
        return 0  # 보증금 정보가 없으면 0 반환

    deposit_text = match.group(1)
    deposit_text = re.sub(r"[^\w\.]", "", deposit_text)  # 공백 및 특수문자 제거 (마침표 허용)
    deposit_text = deposit_text.replace(',', '').replace(' ', '').replace('만', '').replace('원', '')

    uk = 0  # 억 단위 금액 초기화
    cheon = 0  # 천 단위 금액 초기화
    remaining = 0  # 나머지 숫자 초기화

    # "억" 단위 처리
    if "억" in deposit_text:
        uk_match = re.search(r"([\d\.]+)억", deposit_text)
        if uk_match:
            uk = float(uk_match.group(1))  # "억" 앞의 숫자 추출
        # "억"까지의 길이를 찾아 앞부분을 삭제
        uk_index = deposit_text.find("억") + 1  # "억" 위치 +1 (억 자체 포함)
        deposit_text = deposit_text[uk_index:].strip()  # "억" 앞부분 제거
        
    # "천" 단위 처리
    if "천" in deposit_text:
        cheon_match = re.search(r"([\d\.]+)천", deposit_text)
        if cheon_match:
            cheon = float(cheon_match.group(1))  # "천" 앞의 숫자 추출
        # "천"까지의 길이를 찾아 앞부분을 삭제
        cheon_index = deposit_text.find("천") + 1  # "천" 위치 +1 (천 자체 포함)
        deposit_text = deposit_text[cheon_index:].strip()  # "천" 앞부분 제거
        
    # 남은 숫자 처리
    deposit_text = re.sub(r"[^\d]", "", deposit_text)
    if deposit_text.strip():
        try:
            remaining = float(deposit_text)
        except ValueError:
            remaining = 0
    
    # 최종 계산
    return int(uk * 10000 + cheon * 1000 + remaining)


# 금액 문자열에서 '월세', '임대료' 또는 보증금을 추출 함수
def extract_and_convert(description):
    """
    Extracts the monthly rent (월세) from the given description text and converts it to a numerical value.
    Handles a variety of formats for rent representation in Korean real estate descriptions.
    
    Args:
    description (str): The input text containing real estate description.

    Returns:
    float: Extracted monthly rent as a numerical value. Returns NaN if not found or invalid.
    """
    if not isinstance(description, str):
        return np.nan  # Return NaN if the input is not a string
    
    # Patterns to extract 월세, 임대료, or monthly rent-like values
    patterns = [
        r'월세\s*([0-9,]+)', 
        r'월세\s*([0-9,]+)만',     
        r'임대료\s*([0-9,]+)',      
        r'임대료\s*([0-9,]+)만',    
        r'차임\s*([0-9,]+)',    
        r'차임\s*([0-9,]+)만',   
        r'/\s*([0-9,]+)\s*만',  
    ]

    for pattern in patterns:
        match = re.search(pattern, description)
        if match:
            try:
                # Remove commas and convert to a float
                return float(match.group(1).replace(',', ''))
            except ValueError:
                continue

    return np.nan  # Return NaN if no match is found

# 상세설명에 면적 추출 함수
def extract_area(text):
    if pd.isna(text) or not isinstance(text, str):
        return None
    # '면적'과 ':' 사이, ':'와 숫자 '평' 사이에 어떤 문자나 공백이 와도 매칭되도록 패턴 수정
    match = re.search(r'면적.*?:.*?(\d+(\.\d+)?)\s*평', text)
    if match:
        return float(match.group(1))  # 매칭된 숫자 반환 (첫 번째 캡처 그룹)
    return None


# 최종_크롤링에서 체크_매물설명 열 만들기
def check_description(row):
    def to_numeric(value):
        """값을 숫자로 변환하고 결측값 및 공백은 -1로 대체"""
        try:
            value = str(value).strip()  # 공백 제거
            return pd.to_numeric(value, errors='coerce') if value else -1
        except:
            return -1

    # 데이터 타입 변환 (공백 처리 포함)
    row['보증금'] = to_numeric(row['보증금'])
    row['상세설명_보증금'] = to_numeric(row['상세설명_보증금'])
    row['월세'] = to_numeric(row['월세'])
    row['상세설명_월세'] = to_numeric(row['상세설명_월세'])
    row['상세설명_면적'] = to_numeric(row['상세설명_면적'])
    row['전용면적'] = to_numeric(row['전용면적'])
    row['상세설명'] = str(row['상세설명']).strip() if pd.notna(row['상세설명']) else ''  # 공백 제거

    checks = []

    # 로직 (기존 내용 유지)
    if row['백억매물번호'] == '매물번호 오표기':
        checks.append('매물번호')
    if row['보증금'] != -1 and row['상세설명_보증금'] != -1:
        if row['보증금'] != row['상세설명_보증금']:
            checks.append('보증금')
    if row['월세'] != -1 and row['상세설명_월세'] != -1:
        if row['월세'] != row['상세설명_월세']:
            checks.append('월세')
    if row['상세설명_면적'] != -1 and row['전용면적'] != -1:
        if abs(row['상세설명_면적'] - row['전용면적'] * 0.3025) >= 3:
            checks.append('면적')
    if row['부기사_권리금'] == 0 and '무권리' not in row['상세설명']:
        checks.append('무권리 누락')

    return '\n'.join(checks)


def calculate_maintenance_status(value):
    """
    광고_관리비 값에 따라 체크_관리비 상태를 계산하는 함수.
    """
    if value == 0:
        return '관리비 없음'
    elif 1 < value < 10000:
        return '관리비 오표기'
    else: # -1이랑 관리비 있는거랑 공백으로 표시
        return ''

def get_address_from_coordinates(kakao_api_key, latitude, longitude, retries=3, delay=5): # 재시도 기능 추가
    """
    위도, 경도로 지번주소를 반환하는 함수.
    재시도 횟수(retries)와 각 재시도 간의 지연 시간(delay)을 설정할 수 있습니다.
    
    Args:
    kakao_api_key (str): 카카오 API 키.
    latitude (float): 위도.
    longitude (float): 경도.
    retries (int): 실패 시 재시도 횟수 (기본값 3).
    delay (int): 재시도 간 지연 시간 (초, 기본값 5).
    
    Returns:
    str: 지번주소 또는 에러 메시지.
    """
    url = "https://dapi.kakao.com/v2/local/geo/coord2address.json"
    headers = {"Authorization": f"KakaoAK {kakao_api_key}"}
    params = {"x": longitude, "y": latitude}

    for attempt in range(retries):
        try:
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()  # 요청이 실패하면 예외 발생
            result = response.json()
            if 'documents' in result and result['documents']:
                address = result['documents'][0]['address']
                return address['address_name']
            else:
                return "해당 좌표에 대한 주소 정보가 없습니다."
        except requests.exceptions.RequestException as e:
            print(f'에러 발생: {e}. {delay}초 후 재시도합니다. ({attempt+1}/{retries})')
            if attempt < retries - 1:  # 마지막 시도가 아니면 대기 후 재시도
                time.sleep(delay)
            else:
                return f"최종적으로 요청에 실패했습니다. 에러: {e}"

def get_spreadsheet_id_with_retries(func, *args, max_retries=3, delay=2):
    attempt = 0
    while attempt < max_retries:
        try:
            return func(*args)  # Try to execute the function
        except Exception as e:
            attempt += 1
            if attempt < max_retries:
                print(f"Attempt {attempt} failed. Retrying in {delay} seconds...")
                time.sleep(delay)
            else:
                print(f"Failed after {max_retries} attempts.")
                raise e
            
def open_spreadsheet_with_retries(client, spreadsheet_id, max_retries=3, delay=2):
    attempt = 0
    while attempt < max_retries:
        try:
            return client.open_by_key(spreadsheet_id)  # Try to open the spreadsheet
        except Exception as e:
            attempt += 1
            if attempt < max_retries:
                print(f"Attempt {attempt} failed to open spreadsheet. Retrying in {delay} seconds...")
                time.sleep(delay)
            else:
                print(f"Failed to open spreadsheet after {max_retries} attempts.")
                raise e
            
def get_spreadsheet_id_by_name_with_retries(func, drive_data_folder_id, filename, max_retries=3, delay=2):
    attempt = 0
    while attempt < max_retries:
        try:
            return func(drive_data_folder_id, filename)  # Attempt to get the spreadsheet ID
        except Exception as e:
            attempt += 1
            if attempt < max_retries:
                print(f"Attempt {attempt} failed to get spreadsheet ID for '{filename}'. Retrying in {delay} seconds...")
                time.sleep(delay)
            else:
                print(f"Failed to get spreadsheet ID for '{filename}' after {max_retries} attempts.")
                raise e
            
def retry_function(func, *args, **kwargs):
    """
    함수 실행 시 오류 발생 시 재시도를 관리하는 유틸리티 함수.
    """
    attempt = 0
    max_retries=3
    
    while attempt < max_retries:
        try:
            print(f"Attempt {attempt + 1} for {func.__name__}")
            time.sleep(2)
            return func(*args, **kwargs)  # 함수 실행
        except Exception as e:
            print(f"Error on attempt {attempt + 1} for {func.__name__}:")
            traceback.print_exc()  # 전체 오류 메시지와 스택 추적 출력
            attempt += 1
            time.sleep(2)  # 재시도 전 1초 대기
    print(f"{func.__name__} failed after {max_retries} retries")
    return None  # 재시도 실패 후 None 반환

# def extract_representative_address(address):
#     # Trim excessive spaces and apply regex
#     address = re.sub(r'\s+', ' ', address.strip())  # Remove excessive spaces
#     match = re.search(r'(\S+(동|리|면))\s(산?\d+-\d+|산?\d+)', address)
#     if match:
#         return f"{match.group(1)} {match.group(3)}"
#     return address  # Return original if no match found


def extract_representative_address(address):
    # 문자열이 아니면 str로 변환
    if not isinstance(address, str):
        address = str(address)

    address = address.strip()
    if not address:
        return ""

    # 1. 시/군/구 같은 행정구역 앞부분 제거
    address = re.sub(r'^(.*?(시|군|구)\s)+', '', address)

    # 2. 동/리/면 + 산123-4 같은 패턴 추출
    match = re.search(r'(\S+(동|리|면))\s+(산?\d+(-\d+)?)$', address)
    if match:
        result = f"{match.group(1)} {match.group(3)}"
    else:
        result = address  # 매칭 안 되면 원본 반환

    # 3. 괄호 안 텍스트 제거 (예: "(구)" 등)
    result = re.sub(r'\(.*?\)', '', result).strip()

    return result

# 백억지도를 위한 스프레드시트 생성
def save_map_data():
    filename_naverAll = f'네이버_상가_전체_{datetime.now().strftime("%Y%m%d")}'
    spreadsheet_id_naverAll = get_spreadsheet_id_by_name_with_retries(
        get_spreadsheet_id_by_name,
        var.drive_data_folder_id,
        filename_naverAll
    )
    spreadsheet_naverAll = open_spreadsheet_with_retries(
        google_client,
        spreadsheet_id_naverAll
    )
    worksheet_naverAll = spreadsheet_naverAll.get_worksheet(0)
    data = worksheet_naverAll.get_all_values()
    naverAll_df = pd.DataFrame(data[1:], columns=data[0])  # 첫 번째 행을 컬럼 이름으로 사용

    filename_bugisa = f'원본_py_{datetime.now().strftime("%Y%m%d")}'
    spreadsheet_id_bugisa = get_spreadsheet_id_by_name_with_retries(
        get_spreadsheet_id_by_name,
        var.drive_data_folder_id,
        filename_bugisa
    )
    spreadsheet_bugisa = open_spreadsheet_with_retries(
        google_client,
        spreadsheet_id_bugisa
    )
    worksheet_bugisa = spreadsheet_bugisa.get_worksheet(0)
    data = worksheet_bugisa.get_all_values()
    df_bugisa = pd.DataFrame(data[1:], columns=data[0])  # 첫 번째 행을 컬럼 이름으로 사용    

    # '지번주소'와 '상세주소'에서 첫 번째 단어(또는 숫자)만 남기기
    df_bugisa['지번주소'] = df_bugisa['지번주소'].str.split().str[0]
    naverAll_df['상세주소'] = naverAll_df['상세주소'].str.split().str[0]
    naverAll_df = naverAll_df.drop_duplicates(subset=['상세주소'])

    # '상세주소'와 '지번주소'를 기준으로 병합하여 '위도'와 '경도' 추가
    df_bugisa = df_bugisa.merge(naverAll_df[['상세주소', '위도', '경도']], 
                                left_on='지번주소', 
                                right_on='상세주소', 
                                how='left')

    # 불필요한 '상세주소' 열 삭제
    df_bugisa.drop(columns=['상세주소'], inplace=True)
    # 주택물건은 삭제, 
    df_bugisa = df_bugisa[df_bugisa['대분류 1차'] != '주택']


    # 나중에 개발하자. 이거는 지도만들기지..
    df_bugisa = df_bugisa[df_bugisa['대분류 1차'] != '주택']

    # 선택한 열만 유지
    columns_to_select = ['매물번호', '링크', '거래완료 여부', '거래유형', '제목', '위도', '경도'] 
    df_bugisa = df_bugisa[columns_to_select]

    # ---------- 맵데이터 백업 ----------
    filename = f'map_data_{datetime.now().strftime("%Y%m%d")}'
    spreadsheet = create_backup_spreadsheet(filename)
    save_dataframe_to_sheet(spreadsheet.id, df_bugisa, "기본시트")  # 스프레드시트에 저장

# 파일 이름을 받아서 드라이브 폴더에서 찾아서 데이터프레임으로 반환
def open_by_filename(filename):
    spreadsheet_id = get_spreadsheet_id_with_retries(
        get_spreadsheet_id_by_name,
        var.drive_data_folder_id,
        filename
    )

    if spreadsheet_id:
        try:
            print(f"'{filename}' 스프레드시트가 이미 존재합니다. 스프레드시트 ID: {spreadsheet_id}")
            spreadsheet = open_spreadsheet_with_retries(
                google_client,
                spreadsheet_id
            )
            worksheet = spreadsheet.get_worksheet(0)
            data = worksheet.get_all_values()
            df = pd.DataFrame(data[1:], columns=data[0])
            return df
        except APIError as e:
            print(f"API 에러 발생: {e}")
    else:
        print(f"'{filename}' 스프레드시트가 없습니다. update_cog_sheet.py를 실행하세요")


def make_request(url, headers, params=None):
    """GET 요청을 보내고 응답을 JSON으로 반환합니다."""
    try:
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f'요청 중 오류 발생: {e}')
        raise
        
def fetch_article_details(article_no, token):
    """매물 번호에 해당하는 매물 정보를 가져옵니다."""
    API_BASE_URL = 'https://new.land.naver.com'
    user_agent_rotator = UserAgent(
        software_names=[SoftwareName.CHROME.value],
        operating_systems=[OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value],
        limit=100
    )
    
    headers = {
        'authorization': f'Bearer {token}',
        'referer': f'{API_BASE_URL}/offices?ms=35.533817,129.294975,15&a=SG:SMS:GJCG:APTHGJ:GM:TJ&e=RETAIL'
    }

    while True:
        headers['user-agent'] = user_agent_rotator.get_random_user_agent()
        try:
            data = make_request(f'{API_BASE_URL}/api/articles/{article_no}?complexNo=', headers)
            break
        except Exception:
            print('fetch_article_details() 네이버에서 일시적으로 차단당했습니다. (지연시간 3초)')
            time.sleep(3)

    return {  # 매물 상세 정보 반환
        '상세주소': extract_representative_address(get_address_from_coordinates(var.kakao_api_key, data.get('articleDetail', {}).get('latitude', '-'), data.get('articleDetail', {}).get('longitude', '-'))),
        '해당층': data.get('articleFloor', {}).get('correspondingFloorCount', '-').replace('지하', '-').replace('B', '-'),
        '계약면적': data.get('articleSpace', {}).get('supplySpace', '-'),
        '전용면적': data.get('articleSpace', {}).get('exclusiveSpace', '-'),
        '보증금': data.get('articlePrice', {}).get('warrantPrice', '-'),
        '월세': data.get('articlePrice', {}).get('rentPrice', '-'),
        '매물설명': data.get('articleDetail', {}).get('articleFeatureDescription', '-'),
        '상세설명': data.get('articleDetail', {}).get('detailDescription', '-'),
        '중개사': data.get('articleRealtor', {}).get('realtorName', '-'),
        '중개사주소': data.get('articleRealtor', {}).get('address', '-'),
        '매물번호': article_no,
        '광고게시일': data.get('articleAddition', {}).get('articleConfirmYmd', '-'),
        '소유자확인': (
            '모바일v1' if data.get('articleDetail', {}).get('verificationTypeCode', '-') == 'MOBL' else
            '모바일v2' if data.get('articleDetail', {}).get('verificationTypeCode', '-') == 'OWNER' else
            '구홍보' if data.get('articleDetail', {}).get('verificationTypeCode', '-') == 'DOC' else
            '신홍보-개인' if data.get('articleDetail', {}).get('verificationTypeCode', '-') == 'NDOC1' else
            '신홍보-위임' if data.get('articleDetail', {}).get('verificationTypeCode', '-') == 'NDOC2' else
            '현장' if data.get('articleDetail', {}).get('verificationTypeCode', '-') == 'SITE' else
            '-'
        ),
        '총층': data.get('articleFloor', {}).get('totalFloorCount', '-'),
        '융자금': data.get('articlePrice', {}).get('financeTypeCode', '-'),
        '관리비': data.get('articleDetail', {}).get('monthlyManagementCost', '-'),
        '권리금': data.get('articlePrice', {}).get('rightPrice', '-'),
        '광고채널': data.get('articleAddition', {}).get('cpName', '-'),
        '거래방식': data.get('articleAddition', {}).get('tradeTypeName', '-'),
        '지번주소': data.get('articleDetail', {}).get('exposureAddress', '-'),
    }

def wait_for_element(browser, xpath, timeout=2):
    """요소가 로드될 때까지 대기"""
    return WebDriverWait(browser, timeout).until(EC.presence_of_element_located((By.XPATH, xpath)))

def crawling_ad_realtorNum(realtorNum):
    URL = f'https://new.land.naver.com/offices?ms=37.7281683,126.7361052,17&a=SG:GJCG:SMS&b=B2&e=RETAIL&realtorId={realtorNum}'
            
    print("매물번호 수집 시작")

    # 브라우저 실행
    driver = webdriver.Chrome()
    driver.maximize_window()  # 브라우저 창을 최대화
    driver.implicitly_wait(10)
    pyautogui.sleep(2)    

    # 로그인 페이지로 이동
    driver.get(URL)
    driver.implicitly_wait(15)

    # 광고물건의 개수 구하기
    num_items = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH, '//*[@id="summaryInfo"]/div[3]/div/button[3]/span[2]'))  # 요소가 DOM에 존재하는지 확인
    ).text
    
    num_items = int(num_items)
    # num_items = 30

    # 스크롤을 페이지 아래로 내리기
    scrollable_element_xpath = '//*[@id="ct"]/div[2]/div[2]/div/div/div[2]/div'
    scrollable_div = wait_for_element(driver, scrollable_element_xpath)
    
    # 빈 배열 생성
    baikuk_ad_num = []
    
    # XPath 리스트 설정 (첫 번째 XPath, 두 번째 XPath)
    element_xpath_list = [
        '//*[@id="articleListArea"]/div[{i}]/div/a/div[1]/span[2]',  # 첫 번째 XPath
        '//*[@id="articleListArea"]/div[{i}]'  # 두 번째 XPath
    ]

    # 현재 사용할 XPath 인덱스 (0: 첫 번째 XPath, 1: 두 번째 XPath)
    xpath_index = 0  

    for i in range(1, num_items + 1):
        try:
            success = False  # 클릭 성공 여부

            # 두 번의 XPath 시도 (첫 번째 -> 두 번째 -> 첫 번째)
            for attempt in range(2):
                element_xpath = element_xpath_list[xpath_index].format(i=i)  # 현재 XPath 선택
                try:
                    wait_for_element(driver, element_xpath).click()
                    success = True  # 클릭 성공
                    print(f"✅ [{i}/{num_items}] 클릭 성공: XPath={element_xpath}")
                    break  # 성공하면 루프 탈출
                except Exception as e:
                    print(f"❌ [{i}] XPath 오류 발생: XPath={element_xpath}, 오류 내용={e}")
                    xpath_index = (xpath_index + 1) % 2  # XPath를 변경 (0 ↔ 1)

            if not success:
                print(f"❌ [{i}] 모든 XPath 시도 실패, 다음 매물로 이동")
                continue  # 클릭이 실패하면 다음 매물로 이동

            # 매물번호 가져오기
            detail_xpath = '//*[@id="detailContents1"]/div[1]/table/tbody/tr[12]/td[2]'
            element = wait_for_element(driver, detail_xpath, timeout=10)
            baikuk_ad_num.append(element.text)

            # 🔥 i가 19의 배수일 때만 스크롤 실행
            if i % 19 == 0:
                print(f"🔽 스크롤 실행 (i={i})")
                driver.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight;", scrollable_div)

        except Exception as e:
            print(f"❌ [{i}] 번째 매물 오류 발생: {e}")

    print(f"🏠 크롤링 수집완료.")
    driver.quit()  # 브라우저 닫기
    return baikuk_ad_num

# 데이터프레임을 받아 위도, 경도 값을 채워주는 함수
def make_lat_lng(df):
    spreadsheet_lat_lng = open_spreadsheet_with_retries(
        google_client,
        var.lat_lng_key
    )
    worksheet_lat_lng = spreadsheet_lat_lng.get_worksheet(0)
    data = worksheet_lat_lng.get_all_values()
    df_lat_lng = pd.DataFrame(data[1:], columns=data[0])  # 첫 번째 행을 컬럼 이름으로 사용
    
    df = df.drop(columns=['위도', '경도'], errors='ignore')  # 기존 '위도', '경도' 열 제거 (있으면)

    # '위도', '경도' 컬럼이 없으면 NaN 값으로 추가
    for col in ['위도', '경도']:
        if col not in df.columns:
            df[col] = np.nan
    
    df_jibun = df.copy()
    df_jibun = df_jibun.drop_duplicates(subset=['대표주소'], keep='first')  # 첫 번째 행 유지
    df_jibun = df_jibun[['대표주소', '위도', '경도']]

    # ✅ 두 데이터프레임을 그대로 합치기
    df_lat_lng = pd.concat([df_lat_lng, df_jibun], ignore_index=True)

    # ✅ '대표주소' 기준으로 중복 제거 (df_lat_lng 값 유지)
    df_lat_lng = df_lat_lng.drop_duplicates(subset=['대표주소'], keep='first')

    # ✅ '위도', '경도' 값이 NaN, 0, 빈 문자열("")인 경우 업데이트 (대표주소 값이 있는 경우만 실행)
    for idx, row in df_lat_lng.iterrows():
        if (
            pd.isna(row['위도']) or row['위도'] == 0 or str(row['위도']).strip() == "" or
            pd.isna(row['경도']) or row['경도'] == 0 or str(row['경도']).strip() == ""
        ):
            대표주소 = row['대표주소']
            
            if pd.notna(대표주소) and 대표주소.strip():  # 대표주소가 존재할 때만 실행
                lat, lng = get_lat_lng(대표주소, var.KAKAO_API_KEY2)
                
                if lat != 0 and lng != 0:  # 0.0 값이 아닌 경우만 업데이트
                    df_lat_lng.at[idx, '위도'] = lat
                    df_lat_lng.at[idx, '경도'] = lng
                    # print(f"📍 주소 '{대표주소}' → 위도: {lat}, 경도: {lng} 업데이트 완료!")
                else:
                    print(f"⚠️ '{대표주소}'에 대한 위도/경도 정보 없음 (API 응답 0.0)")

    # ✅ NaN 값이 있으면 0으로 변환
    df_lat_lng[['위도', '경도']] = df_lat_lng[['위도', '경도']].fillna(0)
    
    # ✅ '위도' 또는 '경도' 값이 0 또는 NaN인 행 제거
    df_lat_lng = df_lat_lng.dropna(subset=['위도', '경도'])  # NaN 제거
    df_lat_lng = df_lat_lng.query("위도 != 0 and 경도 != 0")  # 0 제거

    save_dataframe_to_sheet(var.lat_lng_key, df_lat_lng, "기본시트")

    # ✅ '대표주소'를 기준으로 '위도', '경도' 값 채우기
    df = df.merge(df_lat_lng, on='대표주소', how='left', suffixes=('', '_latlng'))

    # 기존 '위도', '경도' 값을 새로운 값으로 업데이트 (새 값이 있으면 덮어쓰기)
    df['위도'] = df['위도_latlng'].fillna(df['위도'])
    df['경도'] = df['경도_latlng'].fillna(df['경도'])

    # 중복 컬럼 삭제
    df.drop(columns=['위도_latlng', '경도_latlng'], inplace=True)

    return df

def get_address_from_coordinates_juso(kakao_api_key, latitude, longitude, df_juso, retries=3, delay=5): # 재시도 기능 추가
    """
    위도, 경도로 지번주소를 반환하는 함수.
    재시도 횟수(retries)와 각 재시도 간의 지연 시간(delay)을 설정할 수 있습니다.
    
    Args:
    kakao_api_key (str): 카카오 API 키.
    latitude (float): 위도.
    longitude (float): 경도.
    retries (int): 실패 시 재시도 횟수 (기본값 3).
    delay (int): 재시도 간 지연 시간 (초, 기본값 5).
    
    Returns:
    str: 지번주소 또는 에러 메시지.
    """
    url = "https://dapi.kakao.com/v2/local/geo/coord2address.json"
    headers = {"Authorization": f"KakaoAK {kakao_api_key}"}
    params = {"x": longitude, "y": latitude}

    for attempt in range(retries):
        try:
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()  # 요청이 실패하면 예외 발생
            result = response.json()
            if 'documents' in result and result['documents']:
                address = result['documents'][0]['address']
                new_data = {
                    '위도': latitude,  # latitude 값
                    '경도': longitude,  # longitude 값
                    '지번주소': address['address_name']  # address에서 'address_name' 값
                }
                new_row = pd.DataFrame([new_data])  # 새로운 데이터 단일 행 데이터프레임 생성
                df_juso = pd.concat([df_juso, new_row], ignore_index=True)
                return df_juso
            else:
                new_data = {
                    '위도': latitude,  # latitude 값
                    '경도': longitude,  # longitude 값
                    '지번주소': "해당 좌표에 대한 주소 정보가 없습니다." 
                }
                new_row = pd.DataFrame([new_data])  # 새로운 데이터 단일 행 데이터프레임 생성
                df_juso = pd.concat([df_juso, new_row], ignore_index=True)
                return df_juso
        except requests.exceptions.RequestException as e:
            print(f'에러 발생: {e}. {delay}초 후 재시도합니다. ({attempt+1}/{retries})')
            if attempt < retries - 1:  # 마지막 시도가 아니면 대기 후 재시도
                time.sleep(delay)
            else:
                return f"최종적으로 요청에 실패했습니다. 에러: {e}"
            
def save_dataframe_to_first_sheet(spreadsheet_id, df, chunk_size=25000, retries=3, delay=5):
    """
    DataFrame을 25,000행씩 나눠서 Google 스프레드시트에 저장합니다.

    Parameters:
        spreadsheet_id (str): Google 스프레드시트 ID
        df (pd.DataFrame): 저장할 데이터프레임
        chunk_size (int): 한 번에 저장할 행 수 (기본값: 25,000)
        retries (int): API 실패 시 재시도 횟수
        delay (int): 재시도 간 대기 시간 (초)
    """
    spreadsheet = gc.open_by_key(spreadsheet_id)
    worksheet = spreadsheet.get_worksheet(0)
    
    # 기존 워크시트 내용 비우기
    worksheet.clear()

    total_rows = len(df)
    print(f"전체 {total_rows}행을 {chunk_size}행씩 나눠 저장합니다...")

    for i in range(0, total_rows, chunk_size):
        chunk = df.iloc[i:i + chunk_size]
        print(f"→ {i + 1} ~ {i + len(chunk)} 행 저장 중...")

        for attempt in range(retries):
            try:
                # 첫 번째 청크에만 컬럼 헤더 포함
                if i == 0:
                    set_with_dataframe(worksheet, chunk, row=1, col=1)
                else:
                    set_with_dataframe(worksheet, chunk, row=i + 2, col=1)
                print(f"✅ {i + 1} ~ {i + len(chunk)} 행 저장 완료")
                break
            except APIError as e:
                print(f"⚠️ [재시도 {attempt + 1}/{retries}] 저장 실패: {e}")
                time.sleep(delay)
        else:
            print(f"❌ {i + 1} ~ {i + len(chunk)} 행 저장 최종 실패")

    # 시트 이름 정리
    if worksheet.title != "기본시트":
        worksheet.update_title("기본시트")

    print(f"📄 {spreadsheet.title}에 데이터 저장 완료")

def remove_illegal_characters(text):
    """엑셀 파일에 기록할 수 없는 특수 문자를 제거합니다."""
    if isinstance(text, str):
        # 정규 표현식을 사용하여 문자 중 \x00-\x1F 범위에 해당하는 제어 문자를 제거
        return re.sub(r'[\x00-\x1F\x7F-\x9F]', '', text)
    return text

def get_latest_spreadsheet_id(base_filename, max_retries=5, min_row_threshold=2000):
    """
    base_filename이 '파주' 또는 '고양시'를 포함하는 경우:
        - 최신 파일부터 시작하여 행 수가 min_row_threshold 이하면 하루 전 파일로 최대 max_retries회까지 반복

    그렇지 않은 경우:
        - 기존 최신 파일 하나만 반환

    Returns:
        str or None: 조건에 맞는 파일 ID
    """
    # Google Drive에서 해당 폴더 내 모든 파일 리스트 가져오기
    query = f"'{var.drive_data_folder_id}' in parents and mimeType='application/vnd.google-apps.spreadsheet'"
    results = drive_service.files().list(q=query, fields="files(id, name)").execute()
    files = results.get('files', [])

    # 정규식 패턴으로 '{base_filename}YYYYMMDD' 형식 필터링
    pattern = re.compile(f"{re.escape(base_filename)}(\\d{{8}})")
    matched_files = []

    for file in files:
        match = pattern.search(file["name"])
        if match:
            matched_files.append((file["name"], file["id"], match.group(1)))

    if not matched_files:
        print(f"'{base_filename}*' 패턴에 맞는 파일이 없습니다.")
        return None

    # 날짜 기준 내림차순 정렬
    matched_files.sort(key=lambda x: x[2], reverse=True)

    # ------------------------------
    # 조건 분기
    # ------------------------------
    if '파주' in base_filename or '고양시' in base_filename:
        # ✅ 특수 조건: 최대 5회 반복하며 행 수 확인
        for attempt, (name, file_id, date) in enumerate(matched_files[:max_retries]):
            try:
                print(f"[{attempt+1}/{max_retries}] 파일 확인 중: {name}")
                spreadsheet = open_spreadsheet_with_retries(google_client, file_id)
                worksheet = spreadsheet.get_worksheet(0)
                row_count = len(worksheet.get_all_values())

                print(f"→ 행 개수: {row_count}")
                if row_count > min_row_threshold:
                    print(f"✅ 조건 만족: {name} (행 수 {row_count})")
                    return file_id
            except Exception as e:
                print(f"❌ 오류 발생: {e}")
                continue

        print("조건에 맞는 파일을 찾지 못했습니다.")
        return None
    else:
        # ✅ 일반 조건: 가장 최신 파일 1개 반환
        latest_file_name, latest_file_id, latest_date = matched_files[0]
        print(f"🟢 일반지역: 최신 파일 '{latest_file_name}' 선택")
        return latest_file_id

def get_last_two_words(address):
    """주소 문자열에서 마지막 두 단어를 추출합니다."""
    words = address.split()
    if len(words) >= 2:
        return " ".join(words[-2:])
    elif len(words) == 1:
        return words[0]
    else:
        return ""
    
def update_address_with_floor(row):
    """층 정보에 따라 상세주소 값을 업데이트합니다."""
    address = row['상세주소']
    floor = row['층']

    if floor == '-':
        return address
    try:
        floor_int = int(floor)
        if floor_int < 0:
            return f"{address} 지하 {abs(floor_int)}층"
        elif floor_int > 0:
            return f"{address} {floor_int}층"
        else: # 층이 0인 경우 - 필요하다면 처리
            return address
    except ValueError:
        # 층 값이 숫자로 변환되지 않는 경우 - 필요하다면 처리
        return address
    
def extract_business_type(text):
    if pd.isnull(text):
        return '-'
    # '추천업종' 뒤에 공백 유무 포함한 다양한 패턴 처리
    match = re.search(r'-\s*추천업종\s*[:：]?\s*(.*)', text)
    return match.group(1).strip() if match else '-'

    
def extract_features(text):
    if pd.isnull(text):
        return '-'

    features = []

    # 1. '- 특징' ~ '백억 부동산의 약속' 사이 추출
    pattern_features = r'-\s*특징\s*(.*?)\s*백\s*억\s*부\s*동\s*산\s*의\s*약\s*속'
    match = re.search(pattern_features, text, re.DOTALL)
    if match:
        features_text = re.sub(r'\s+', ' ', match.group(1)).strip()
        features.append(f"◆{features_text}◆")

    # 2. '- 위치' 추출
    pattern_location = r'-\s*위치\s*[:：]?\s*(.*)'
    match = re.search(pattern_location, text)
    if match:
        location_line = match.group(1).strip()
        location = location_line.split('\n')[0].strip()
        features.append(f"★{location}★")

    # 3. '- 화장실' 추출
    pattern_toilet = r'-\s*화장실\s*[:：]?\s*(.*)'
    match = re.search(pattern_toilet, text)
    if match:
        toilet_line = match.group(1).strip()
        toilet = toilet_line.split('\n')[0].strip()
        features.append(f"●{toilet}●")

    # 4. '- 추천업종' 추출
    pattern_recommend = r'-\s*추천업종\s*[:：]?\s*(.*)'
    match = re.search(pattern_recommend, text)
    if match:
        rec_line = match.group(1).strip()
        recommend = rec_line.split('\n')[0].strip()
        features.append(f"■{recommend}■")

    if features:
        return ' | '.join(features)
    else:
        return '-'

# '지하' 포함 시 음수 처리
def adjust_floor(row):
    층값 = row['층']
    if '지하' in str(row.get('호수정보', '')) or '지하' in str(row.get('제목', '')):
        try:
            return -abs(int(층값))
        except:
            return 층값  # 변환 실패 시 원래 값 유지
    return 층값

# 상세설명에서 용도 추출
def extract_building_usage(text):
    if pd.isna(text):
        return ''
    # 정규표현식: '-용도:', '- 용도:', '-용도 :', '- 용도:' 등을 포함
    match = re.search(r'-\s*용도\s*:\s*(.*?)(\n|$)', str(text))
    if match:
        return match.group(1).strip()
    return ''

# 화장실 정보 추출
def extract_restroom_location(text):
    if pd.isna(text):
        return ''
    # '-화장실:' 또는 '- 화장실 :' 등 다양한 패턴을 허용하고, 그 뒤에 나오는 문자열을 줄바꿈 전까지 추출
    match = re.search(r'-\s*화장실\s*:\s*(.*?)(\n|$)', str(text))
    if match:
        return match.group(1).strip()
    return ''



def regenerate_all_lat_lng(df, supabase_client, api_key):
    """
    Supabase의 only_lat_lng 테이블을 불러와 기존 위경도를 먼저 매핑하고,
    누락된 주소만 Kakao API로 요청하여 lat_lng 테이블 및 only_lat_lng 테이블에 저장한다.
    """
    DEFAULT_LAT = round(37.761573, 6)
    DEFAULT_LNG = round(126.669886, 6)

    print("📥 Supabase only_lat_lng 테이블에서 기존 위경도 데이터 불러오는 중...")
    try:
        result = supabase_client.table("only_lat_lng").select("*").execute()
        only_lat_lng_data = result.data
        df_only = pd.DataFrame(only_lat_lng_data)
        df_only['addr_compare'] = df_only['full_address'].astype(str).str.replace(r"\s+", "", regex=True)
    except Exception as e:
        print(f"❌ Supabase only_lat_lng 데이터 불러오기 실패: {e}")
        return df

    # 원본 데이터 준비
    df_copy = df.copy()
    df_copy['주소원본'] = df_copy['지번주소'].astype(str).str.strip()
    df_copy['addr_compare'] = df_copy['주소원본'].str.replace(r"\s+", "", regex=True)
    df_copy['위도'] = 0.0
    df_copy['경도'] = 0.0

    # 기존 only_lat_lng로 매핑
    merged = pd.merge(df_copy, df_only[['addr_compare', 'lat', 'lng']], on='addr_compare', how='left')
    df_copy['위도'] = merged['lat'].fillna(0.0)
    df_copy['경도'] = merged['lng'].fillna(0.0)
    print(f"✅ 기존 Supabase 위경도 데이터로 채워진 주소 수: {(df_copy['위도'] != 0.0).sum()}")

    # Kakao API 대상 주소
    missing_df = df_copy[df_copy['위도'] == 0.0].copy()
    unique_addresses = missing_df['주소원본'].dropna().unique()
    print(f"📍 Kakao API 요청 대상 주소 수: {len(unique_addresses)}")

    # 현황2 불러오기
    spreadsheet = open_spreadsheet_with_retries(google_client, var.store_info)
    worksheet = spreadsheet.worksheet("현황2")
    data = worksheet.get_all_values()
    df_store_info = pd.DataFrame(data[1:], columns=data[0])
    df_store_info['주소원본'] = df_store_info['주소'].astype(str).str.strip()
    df_store_info['addr_compare'] = df_store_info['주소원본'].str.replace(r"\s+", "", regex=True)

    secret_note_df = df_copy[df_copy['매물명'].astype(str).str.contains('관리소', na=False)]

    new_records = []
    for addr in unique_addresses:
        if not addr or addr.strip() in ["", "-", "0"]:
            continue

        lat, lng = get_lat_lng(addr, api_key)
        lat = round(lat if lat else DEFAULT_LAT, 6)
        lng = round(lng if lng else DEFAULT_LNG, 6)

        addr_compare = addr.replace(" ", "")
        store_address = df_store_info[df_store_info['addr_compare'] == addr_compare]['주소원본'].values
        address_to_save = store_address[0] if len(store_address) > 0 else addr

        building_name = df_store_info[df_store_info['addr_compare'] == addr_compare]['건물명'].values
        if len(building_name) == 0:
            building_name = df_copy[df_copy['addr_compare'] == addr_compare]['건물명'].values
        building_name = building_name[0] if len(building_name) > 0 else "-"

        matched_notes = secret_note_df[secret_note_df['addr_compare'] == addr_compare]['비밀메모'].dropna().unique()
        building_info = matched_notes[0] if len(matched_notes) > 0 else "-"

        new_records.append({
            'address': address_to_save,
            'addr_compare': addr_compare,
            'lat': lat,
            'lng': lng,
            'building_name': building_name,
            'building_info': building_info
        })

        # df_copy 갱신
        df_copy.loc[df_copy['addr_compare'] == addr_compare, '위도'] = lat
        df_copy.loc[df_copy['addr_compare'] == addr_compare, '경도'] = lng

    print(f"✅ Kakao API로 새로 생성된 위경도 수: {len(new_records)}")

    # lat_lng 테이블 저장
    try:
        print("🧹 Supabase lat_lng 테이블 초기화 중...")
        supabase_client.table("lat_lng").delete().neq("address", "").execute()

        all_records = df_copy[['주소원본', 'addr_compare', '위도', '경도']].drop_duplicates()
        all_records = all_records.rename(columns={
            '주소원본': 'address',
            '경도': 'lng',
            '위도': 'lat'
        })
        all_records['building_name'] = "-"
        all_records['building_info'] = "-"

        update_dict = {r['addr_compare']: r for r in new_records}
        for r in all_records.to_dict('records'):
            key = r['addr_compare']
            if key in update_dict:
                r['building_name'] = update_dict[key]['building_name']
                r['building_info'] = update_dict[key]['building_info']

        supabase_client.table("lat_lng").insert(all_records).execute()
        print("✅ Supabase lat_lng 테이블 재생성 완료")

        # only_lat_lng 신규 주소 저장
        print("📤 Supabase only_lat_lng 테이블에 신규 주소 저장 중...")
        new_only_lat_lng_records = [
            {
                'full_address': r['address'],
                'lat': r['lat'],
                'lng': r['lng']
            }
            for r in new_records
            if r['address'].strip() not in ["", "-", "0"]
        ]

        if new_only_lat_lng_records:
            supabase_client.table("only_lat_lng").upsert(
                new_only_lat_lng_records,
                on_conflict="full_address"
            ).execute()
            print(f"✅ only_lat_lng에 {len(new_only_lat_lng_records)}건 저장 완료")
        else:
            print("ℹ️ 저장할 신규 주소가 없습니다.")
    except Exception as e:
        print(f"❌ Supabase 저장 실패: {e}")

    return df_copy






#supabase 데이터 로드함수
def fetch_all_rows_from_supabase_table(client, table_name, batch_size=999, verbose=True):
    """
    Supabase 테이블에서 데이터를 999건씩 반복적으로 정확히 끝까지 불러오는 함수
    """
    all_rows = []
    offset = 0
    batch_num = 1

    while True:
        if verbose:
            print(f"📦 Fetching batch {batch_num} (range {offset}~{offset + batch_size - 1})...")

        response = client.table(table_name).select("*").range(offset, offset + batch_size - 1).execute()
        rows = response.data or []

        # ✅ 데이터가 없으면 종료
        if not rows:
            print("✅ No more data to fetch.")
            break

        all_rows.extend(rows)

        # ✅ 종료 조건: 실제로 받아온 rows가 0보다 크고 batch_size보다 작으면 끝 (이전 오류 방지)
        if len(rows) == 0:
            break

        # ✅ 다음 배치로 이동
        offset += batch_size
        batch_num += 1

    print(f"🎯 Total rows fetched: {len(all_rows)}")
    return pd.DataFrame(all_rows)

def fill_missing_building_name(row, store_info_df):
    compare_address = row['addr_compare']
    current_name = str(row.get('건물명', '')).strip()

    # 유효한 건물명은 그대로 반환
    if current_name and current_name != '-':
        return current_name

    # 해당 주소와 일치하는 행의 인덱스 목록
    match_indices = store_info_df.index[store_info_df['addr_compare'] == compare_address].tolist()

    for base_idx in match_indices:
        for offset in range(5):  # 다음 5행까지 확인
            target_idx = base_idx + offset
            if target_idx >= len(store_info_df):
                break
            candidate_name = str(store_info_df.at[target_idx, '건물명']).strip()
            if candidate_name and candidate_name != '-':
                return candidate_name

    return '-'  # 유효한 값이 없을 경우 기본값 반환


# subapbase 데이터 삭제 함수
def delete_all_supabase_data(SUPABASE_URL, SUPABASE_TABLE):
    HEADERS = {
        "apikey": var.SUPABASE_API_KEY,
        "Authorization": f"Bearer {var.SUPABASE_API_KEY}",
        "Content-Type": "application/json",
        "Prefer": "return=minimal"
    }

    print("🗑️ Supabase 기존 데이터 전체 삭제 중...")

    # ✅ 테이블 이름에 따라 분기
    if SUPABASE_TABLE == "only_lat_lng":
        # NULL이 아닌 주소만 삭제 (사실상 대부분)
        delete_url = f"{SUPABASE_URL}/rest/v1/{SUPABASE_TABLE}?full_address=not.is.null"

    elif SUPABASE_TABLE in ["baikukdbtest", "baikukdbtest2", "building_info"]:
        # 숫자 비교는 그대로 neq 사용 가능
        delete_url = f"{SUPABASE_URL}/rest/v1/{SUPABASE_TABLE}?listing_id=neq.0"

    elif SUPABASE_TABLE == "work_log":
        # (A) 전부 삭제하려면: PK/uuid NOT NULL 조건
        delete_url = f"{SUPABASE_URL}/rest/v1/{SUPABASE_TABLE}?id=not.is.null"
        
    else:
        print(f"❌ 알 수 없는 테이블 이름: {SUPABASE_TABLE} — 삭제 조건을 지정해주세요.")
        return

    # DELETE 요청 실행
    try:
        res = requests.delete(delete_url, headers=HEADERS, timeout=60)
        if res.status_code in [200, 204]:
            print("✅ 전체 데이터 삭제 완료")
        else:
            print(f"❌ 삭제 실패: {res.status_code} - {res.text}")
    except requests.exceptions.Timeout:
        print("⏱️ 삭제 중 타임아웃 발생 – 재시도 또는 슬라이스 삭제 필요")
    except Exception as e:
        print(f"❌ 삭제 오류: {e}")


def update_supabase(df, SUPABASE_URL, SUPABASE_TABLE):
    HEADERS = {
        "apikey": var.SUPABASE_API_KEY,
        "Authorization": f"Bearer {var.SUPABASE_API_KEY}",
        "Content-Type": "application/json",
        "Prefer": "return=minimal"
    }
    print("📤 Supabase에 데이터 업로드 중...")

    # ✅ 기존 데이터 전체 삭제
    try:
        delete_all_supabase_data(SUPABASE_URL, SUPABASE_TABLE)
        print("⚠️ 기존 데이터 삭제 성공")
    except Exception as e:
        print(f"❌ 기존 데이터 삭제 실패: {e}")
        print("⛔ 업로드 중단됨. 기존 데이터 삭제를 먼저 완료해야 합니다.")
        return

    # ✅ 직렬화 가능한 형태로 변환
    def make_serializable(val):
        if pd.isna(val):
            return None
        if isinstance(val, (np.int64, np.float64)):
            return val.item()
        if isinstance(val, pd.Timestamp):
            return val.strftime('%Y-%m-%d')
        return val

    records = df.to_dict(orient='records')
    # 이 부분을 이렇게 수정해보세요
    serializable_records = [
        {k: make_serializable(v) for k, v in record.items() if pd.notna(v)}
        for record in records
    ]

    batch_size = 1000
    for i in range(0, len(serializable_records), batch_size):
        batch = serializable_records[i:i + batch_size]
        insert_url = f"{SUPABASE_URL}/rest/v1/{SUPABASE_TABLE}?on_conflict=listing_id"

        try:
            response = requests.post(
                insert_url,
                headers=HEADERS,
                json=batch,  # ✅ json 파라미터 사용 (자동 직렬화)
                timeout=60
            )

            if response.status_code in [200, 201]:
                print(f"✅ {i + 1}~{i + len(batch)}행 업로드 성공")
            else:
                print(f"❌ 업로드 실패: {response.status_code} - {response.text}")
                break
        except requests.exceptions.Timeout:
            print("⏱️ 업로드 중 타임아웃 발생 – 재시도 필요")
            break
        except Exception as e:
            print("🚨 예기치 못한 업로드 에러 발생:", e)
            break

    # ✅ 업로드 후 엑셀 저장
    today_str_temp = datetime.today().strftime("%Y%m%d")
    filename_temp = f"업로드완료_{SUPABASE_TABLE}_{today_str_temp}.xlsx"
    try:
        df.to_excel(filename_temp, index=False)
        print(f"📁 데이터프레임 엑셀로 저장 완료: {filename_temp}")
    except Exception as e:
        print(f"❌ 엑셀 저장 실패: {e}")
        
# Supabase에 데이터 업서트
def upsert_supabase(df, SUPABASE_URL, SUPABASE_TABLE, SUPABASE_API_KEY, conflict_key='listing_id'):

    HEADERS = {
        "apikey": SUPABASE_API_KEY,
        "Authorization": f"Bearer {SUPABASE_API_KEY}",
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates"
    }

    # 모든 값 직렬화 처리
    def make_serializable(val):
        if pd.isna(val) or val in ['nan', 'null', 'none', '']:
            return None
        if isinstance(val, (np.integer, np.floating)):
            return val.item()
        if isinstance(val, pd.Timestamp):
            return val.strftime('%Y-%m-%dT%H:%M:%S')  # ISO 8601
        return val

    # NaN → None 처리, Timestamp 문자열 변환
    df_cleaned = df.where(pd.notnull(df), None)

    # 모든 컬럼 보장된 상태로 dict 변환
    all_columns = list(df_cleaned.columns)
    records = df_cleaned.to_dict(orient='records')

    serializable_records = []
    for record in records:
        # 누락된 key 보완 + 값 직렬화
        full_record = {col: None for col in all_columns}
        full_record.update({k: make_serializable(v) for k, v in record.items()})
        serializable_records.append(full_record)

    batch_size = 1000
    for i in range(0, len(serializable_records), batch_size):
        batch = serializable_records[i:i + batch_size]
        insert_url = f"{SUPABASE_URL}/rest/v1/{SUPABASE_TABLE}?on_conflict={conflict_key}"

        try:
            response = requests.post(
                insert_url,
                headers=HEADERS,
                json=batch,
                timeout=60
            )

            if response.status_code in [200, 201]:
                print(f"✅ {i + 1}~{i + len(batch)}행 upsert 성공")

            elif response.status_code == 409 and "duplicate key value" in response.text:
                print(f"⚠️ 중복 키 발생 - 삭제 후 재삽입 시도: {response.text}")

                for record in batch:
                    key_val = record.get(conflict_key)
                    if key_val is None:
                        continue

                    # 삭제
                    delete_url = f"{SUPABASE_URL}/rest/v1/{SUPABASE_TABLE}?{conflict_key}=eq.{key_val}"
                    delete_res = requests.delete(delete_url, headers=HEADERS)

                    if delete_res.status_code in [200, 204]:
                        print(f"🗑️ 중복 키 삭제 성공: {key_val}")

                        # 재삽입
                        retry_res = requests.post(
                            f"{SUPABASE_URL}/rest/v1/{SUPABASE_TABLE}",
                            headers=HEADERS,
                            json=[record]
                        )
                        if retry_res.status_code in [200, 201]:
                            print(f"✅ {key_val} 재삽입 성공")
                        else:
                            print(f"❌ {key_val} 재삽입 실패: {retry_res.status_code} - {retry_res.text}")
                    else:
                        print(f"❌ 중복 키 삭제 실패: {delete_res.status_code} - {delete_res.text}")
            else:
                print(f"❌ upsert 실패: {response.status_code} - {response.text}")
                break

        except requests.exceptions.Timeout:
            print("⏱️ 업로드 중 타임아웃 발생 – 재시도 필요")
            break
        except Exception as e:
            print("🚨 예기치 못한 업로드 에러 발생:", e)
            break

    print("📦 Supabase upsert 완료")

# 데이터프레임 엑셀로 저장
def save_df_to_excel(df, filename_prefix='bugisa'):
    """
    df 엑셀 파일로 저장합니다.
    
    Parameters:
        df (pd.DataFrame): 저장할 데이터프레임
        filename_prefix (str): 저장할 파일 이름의 접두어 (기본값: 'bugisa')
    """
    today_str = datetime.today().strftime('%Y%m%d')
    filename = f"{filename_prefix}_{today_str}.xlsx"

    try:
        df.to_excel(filename, index=False)
        print(f"📁 엑셀 저장 완료: {filename}")
    except Exception as e:
        print(f"❌ 엑셀 저장 실패: {e}")

def add_data_from_supabase(df, supabase_client, api_key):
    DEFAULT_LAT = round(37.761573, 6)
    DEFAULT_LNG = round(126.669886, 6)

    result_df = df.copy()
    result_df['위도'] = 0.0
    result_df['경도'] = 0.0

    # ✅ 주소 원본 + 비교용 버전 생성
    result_df['주소원본'] = result_df['지번주소'].astype(str).str.strip()
    result_df['addr_compare'] = result_df['주소원본'].str.replace(r'\s+', '', regex=True)

    # ✅ 현황2 시트에서 주소 + 건물명 정보 불러오기
    spreadsheet = open_spreadsheet_with_retries(google_client, var.store_info)
    worksheet = spreadsheet.worksheet("현황2")
    data = worksheet.get_all_values()
    df_store_info = pd.DataFrame(data[1:], columns=data[0])
    df_store_info['주소원본'] = df_store_info['주소'].astype(str).str.strip()
    df_store_info['addr_compare'] = df_store_info['주소원본'].str.replace(r'\s+', '', regex=True)

    # lat_lng 테이블 전체 불러오기
    supabase_df = fetch_all_rows_from_supabase_table(supabase_client, "lat_lng")
    supabase_df['address원본'] = supabase_df['address'].astype(str).str.strip()
    supabase_df['addr_compare'] = supabase_df['address원본'].str.replace(r'\s+', '', regex=True)
    supabase_df.drop(columns=['address원본'], inplace=True, errors='ignore')


    # ✅ Supabase 병합 (위도/경도)
    supabase_merged_df = supabase_df[['addr_compare', 'lat', 'lng']].dropna()
    merged = pd.merge(result_df, supabase_merged_df, on='addr_compare', how='left', suffixes=('', '_supabase'))
    result_df['위도'] = merged['lat'].fillna(DEFAULT_LAT).round(6)
    result_df['경도'] = merged['lng'].fillna(DEFAULT_LNG).round(6)
    
    # 보완 적용 (dict 인덱싱을 위해 미리 주소비교 기준 딕셔너리 생성)
    store_info_dict = df_store_info.set_index('addr_compare')['건물명'].to_dict()

    # 각 행에 대해 보완 함수 적용
    # 함수 호출 시 dict가 아닌 df_store_info를 전달
    result_df['건물명'] = result_df.apply(lambda row: fill_missing_building_name(row, df_store_info), axis=1)


    print("✅ result_df의 건물명 보완 완료")


    # ✅ result_df의 건물명 열이 있는 경우, supabase_df에 건물명 매핑
    if '건물명' in result_df.columns:
        # 'addr_compare' 기준으로 '건물명' 가져오기
        building_name_map = result_df.set_index('addr_compare')['건물명'].dropna().to_dict()

        # supabase_df에 매핑 적용
        supabase_df['building_name'] = supabase_df['addr_compare'].map(building_name_map).fillna(supabase_df.get('building_name', '-'))

        print("🏢 Supabase에 건물명 매핑 완료")
    else:
        print("⚠️ result_df에 '건물명' 열이 없어 건물명 매핑을 건너뜀")

    관리소_df = result_df[result_df['매물명'].astype(str).str.contains('관리소', na=False)].copy()
    # 1. 관리소_df에서 'addr_compare' → '비밀메모' 딕셔너리 생성
    secret_note_map = 관리소_df.set_index('addr_compare')['비밀메모'].dropna().to_dict()

    # 2. supabase_df의 'addr_compare' 기준으로 'building_info' 컬럼 채우기
    supabase_df['building_info'] = supabase_df['addr_compare'].map(secret_note_map).fillna(supabase_df.get('building_info', '-'))

    print("✅ Supabase에 building_info 보완 완료")


    # supabase에 저장
    if not supabase_df.empty:
        try:
            update_supabase(supabase_df, var.SUPABASE_URL, var.SUPABASE_TABLE_LAT_LUG)

            print(f"✅ Supabase에 총 {len(supabase_df)}건 저장 완료")
        except Exception as e:
            print(f"❌ Supabase 저장 실패: {e}")

    return result_df

def fill_missing_lat_lng(df, api_key):
    """
    위도/경도 값이 0 또는 누락된 행들에 대해 Kakao API를 사용하여 좌표를 채움

    :param df: DataFrame (지번주소, 위도, 경도 포함)
    :param api_key: 카카오 REST API 키
    :return: 보완된 DataFrame 반환
    """
    updated = 0
    for idx, row in df.iterrows():
        if row.get('위도', 0) == 0 or row.get('경도', 0) == 0:
            address = row.get('지번주소', '')
            if not address or address.strip() == '':
                continue
            lat, lng = get_lat_lng(address, api_key)
            df.at[idx, '위도'] = lat
            df.at[idx, '경도'] = lng
            updated += 1

    print(f"✅ 카카오 API를 통해 위/경도 {updated}건 보완 완료")
    return df


# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def fetch_supabase_table_as_df(
    supabase_url: str, 
    supabase_key: str, 
    table_name: str, 
    pk_column: str
) -> pd.DataFrame:
    """
    Supabase 테이블 전체 데이터를 페이지네이션으로 가져와 Pandas DataFrame으로 반환합니다.
    (개선된 버전: 불필요한 확인 로직을 제거하여 효율성과 가독성을 높였습니다.)

    Args:
        supabase_url (str): Supabase 프로젝트 URL
        supabase_key (str): Supabase anon key
        table_name (str): 조회할 테이블 이름
        pk_column (str): 행 개수 조회에 사용할 기본 키 또는 고유 컬럼

    Returns:
        pd.DataFrame: 테이블 전체 데이터가 담긴 DataFrame
    """
    try:
        supabase: Client = create_client(supabase_url, supabase_key)

        # --- 개선점 1: 전체 행 개수를 먼저, 효율적으로 조회 ---
        # limit(0)을 사용하면 데이터는 가져오지 않고 'count'만 정확히 얻을 수 있습니다.
        count_response = (
            supabase.table(table_name)
            .select(pk_column, count="exact")
            .limit(0) 
            .execute()
        )
        
        total_count = count_response.count
        if total_count is None:
            logger.error("❌ 전체 행 개수를 가져오는 데 실패했습니다.")
            return pd.DataFrame()

        logger.info(f"📊 조회할 전체 행 개수: {total_count}")

        if total_count == 0:
            logger.info("✅ 테이블에 데이터가 없어 빈 DataFrame을 반환합니다.")
            return pd.DataFrame()

        all_data = []
        page_size = 1000  # Supabase의 최대 페이지 사이즈는 1000입니다.
        offset = 0

        # --- 개선점 2: 간결해진 반복문 ---
        # 전체 행 개수에 도달할 때까지 루프를 실행합니다.
        # 불필요한 마지막 페이지 확인 로직이 필요 없습니다.
        while offset < total_count:
            logger.info(f"📥 {offset} ~ {offset + page_size - 1} 행을 가져오는 중...")
            
            response = (
                supabase.table(table_name)
                .select("*")
                .range(offset, offset + page_size - 1)
                .execute()
            )

            if not hasattr(response, "data") or not response.data:
                logger.warning(f"⚠️ offset {offset}에서 데이터를 받지 못했습니다. 중단합니다.")
                break
            
            all_data.extend(response.data)
            offset += page_size

        logger.info(f"✅ 데이터 로딩 완료! 총 {len(all_data)}개의 행을 가져왔습니다.")
        
        return pd.DataFrame(all_data)

    # --- 개선점 3: 포괄적인 오류 처리 ---
    except Exception as e:
        logger.error(f"🚨 함수 실행 중 오류가 발생했습니다: {e}")
        return pd.DataFrame()

# --- 함수 사용 예시 ---
# SUPABASE_URL = "YOUR_SUPABASE_URL"
# SUPABASE_KEY = "YOUR_SUPABASE_KEY"
# TABLE_NAME = "your_table"
# PK_COLUMN = "id" # 테이블의 기본 키

# df = fetch_supabase_table_as_df_improved(SUPABASE_URL, SUPABASE_KEY, TABLE_NAME, PK_COLUMN)
# if not df.empty:
#     print("\n--- 불러온 데이터 ---")
#     print(df.head())
