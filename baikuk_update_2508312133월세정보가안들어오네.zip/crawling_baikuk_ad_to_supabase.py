from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
import undetected_chromedriver as uc
import chromedriver_autoinstaller
import time
import random
from random_user_agent.user_agent import UserAgent
from random_user_agent.params import SoftwareName, OperatingSystem
import pyautogui
import os
from datetime import datetime, timedelta
import gspread
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from oauth2client.service_account import ServiceAccountCredentials
import pandas as pd
from gspread_dataframe import get_as_dataframe
from gspread_dataframe import set_with_dataframe
from gspread.exceptions import APIError
import re
import requests
from bs4 import BeautifulSoup
import signal
import var
import baikukFunction
import csv
import os
from lxml import html

# 초기 입력값: 날짜형식
today_Ymd = datetime.today().strftime('%Y%m%d')
today_Ymd2 = datetime.today().strftime('%Y-%m-%d')
today_ymd = datetime.today().strftime('%Y%m%d')
today_Y_m_d = datetime.today().strftime('%Y_%m_%d')

# Google API 인증 설정
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name(var.json_site, scope)
client = gspread.authorize(creds)

# OAuth 2.0 인증 파일 경로 설정 (구글드라이브 관련)
scopes = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive'
]
credentials = Credentials.from_service_account_file(f'{var.json_site}', scopes=scopes)

# Google Sheets 및 Drive API 초기화
gc = gspread.authorize(credentials)
drive_service = build('drive', 'v3', credentials=credentials)

# 기본 설정
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/138.0.0.0 Safari/537.36"
)
API_BASE_URL = 'https://new.land.naver.com'
# 크롬 드라이버 자동 설치
chromedriver_autoinstaller.install()

# 크롬 옵션 설정
chrome_options = uc.ChromeOptions()
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=http://homesdid.co.kr/mmc/")
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=https://baikuk.com/") 
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=http://homesdid.co.kr/mmc/") 
chrome_options.add_argument('--disable-blink-features=AutomationControlled')

# ✅ 브라우저처럼 보이도록 설정
chrome_options.add_argument(f"--user-agent={USER_AGENT}")


pyautogui.FAILSAFE = False

# 프로그램 종료 플래그
should_terminate = False

# SIGINT 핸들러 정의
def signal_handler(sig, frame):
    global should_terminate
    print('Ctrl+C 입력됨. 프로그램을 중지하고 데이터를 저장합니다...')
    should_terminate = True

# SIGINT 핸들러 등록
signal.signal(signal.SIGINT, signal_handler)

def _clean(s: str) -> str:
    if s is None:
        return ""
    # 공백 정리
    return " ".join(s.split())

def click_all_item_links(driver, pause=1.0, max_clicks=None):
    """
    #articleListArea 내부 a.item_link를 차례대로 클릭하고,
    상세 패널(#detailContents1)에서 가격과 매물정보 테이블을 파싱해 반환.
    """
    wait = WebDriverWait(driver, 10)

    # 리스트 대기
    wait.until(EC.presence_of_element_located((By.ID, "articleListArea")))
    list_area = driver.find_element(By.ID, "articleListArea")

    results = []          # ← 수집한 결과들이 여기에 쌓임
    clicked = 0
    last_count = -1

    def load_more():
        driver.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight;", list_area)
        time.sleep(pause)

    while True:
        anchors = driver.find_elements(By.CSS_SELECTOR, "#articleListArea a.item_link")
        cur_count = len(anchors)

        if cur_count == last_count:
            load_more()
            anchors = driver.find_elements(By.CSS_SELECTOR, "#articleListArea a.item_link")
            if len(anchors) == last_count:
                break
        last_count = cur_count

        for i in range(clicked, cur_count):
            if max_clicks and len(results) >= max_clicks:
                return results

            try:
                a = anchors[i]
                driver.execute_script("arguments[0].scrollIntoView({block:'center'});", a)
                time.sleep(0.2)
                try:
                    a.click()
                except Exception:
                    driver.execute_script("arguments[0].click();", a)

                # 상세 패널 로딩
                try:
                    wait.until(EC.presence_of_element_located((By.ID, "detailContents1")))
                except TimeoutException:
                    time.sleep(0.5)

                # ---------- HTML 파싱 시작 ----------
                tree = html.fromstring(driver.page_source)

                # 1) rent_type: 지정한 절대 XPath의 하위 텍스트 전부 수집
                rent_type = ""
                rent_node = tree.xpath('//*[@id="ct"]/div[2]/div[2]/div/div[2]/div[2]/div[1]/div[3]')
                if rent_node:
                    # 하위 모든 텍스트를 긁어서 공백 정리 후 합쳐서 저장
                    rent_parts = [_clean(t) for t in rent_node[0].xpath('.//text()') if _clean(t)]
                    rent_type = " ".join(rent_parts)

                # 원래 쓰시던 상대/클래스 기반이 더 안정적일 때는 fallback으로 유지하고 싶다면:
                if not rent_type:
                    rent_type = _clean("".join(
                        tree.xpath(
                            '//*[@id="detailContents1"]'
                            '//div[contains(@class,"info_article_price")]'
                            '//span[contains(@class,"type")]/text()'
                        )
                    ))

                # 2) 매물정보 테이블(tbody) 전부 → dict
                info_map = {}
                rows = tree.xpath(
                    '//*[@id="detailContents1"]//table//tbody/tr'
                )
                for row in rows:
                    th = _clean("".join(row.xpath('./th//text()')))
                    # 여러 TD가 있으면 모두 합침
                    tds_text = [_clean("".join(td.xpath('.//text()'))) for td in row.xpath('./td')]
                    val = " / ".join([t for t in tds_text if t])
                    if th or val:
                        # 키 중복되면 뒤에 (2), (3) 붙여서 보존
                        key = th if th else f"ROW_{len(info_map)+1}"
                        if key in info_map:
                            k2 = key
                            n = 2
                            while k2 in info_map:
                                k2 = f"{key}({n})"
                                n += 1
                            key = k2
                        info_map[key] = val


                result = {
                    "index": i + 1,
                    "rent_type": rent_type,
                    "details": info_map           # tbody 테이블 전체 dict
                }

                results.append(result)
                # === 매물 단위 출력 ===
                print("="*60)
                print(f"[{i+1}] 매물 수집 완료")
                print(f"유형: {rent_type}")
                print(f"상세항목 {len(info_map)}개")
                for k, v in info_map.items():
                    print(f" - {k}: {v}")
                print("="*60)

                print(f"✅ 수집 완료: {i+1}/{cur_count}")
                input("계속...")

            except (StaleElementReferenceException, TimeoutException):
                # DOM 갱신 시 스킵하고 계속
                continue
            except Exception as e:
                print(f"⚠️ 항목 {i+1} 실패: {e}")

        load_more()

    return results

def wait_for_list_ready(driver, timeout=20):
    WebDriverWait(driver, timeout).until(
        EC.any_of(
            EC.presence_of_element_located((By.CSS_SELECTOR, "#articleListArea")),
            EC.presence_of_element_located((By.CSS_SELECTOR, "div.item_list--article"))
        )
    )
    # 내부 스크롤 한번 태워서 초기 렌더 트리거
    try:
        list_area = driver.find_element(By.CSS_SELECTOR, "#articleListArea, div.item_list--article")
        driver.execute_script("arguments[0].scrollTop = 200;", list_area)
        time.sleep(0.8)
    except Exception:
        pass
    # 앵커가 최소 1개 나올 때까지 대기
    WebDriverWait(driver, timeout).until(
        EC.presence_of_all_elements_located((By.CSS_SELECTOR, "#articleListArea a.item_link, div.item_list--article a.item_link"))
    )


def crawl_all_articles():    
    driver = uc.Chrome(options=chrome_options)
    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": """
            Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
            window.navigator.chrome = { runtime: {} };
            Object.defineProperty(navigator, 'languages', { get: () => ['ko-KR', 'ko'] });
            Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3] });
        """
    })

    driver.maximize_window()  # 브라우저 창을 최대화
    driver.implicitly_wait(10)
    time.sleep(random.uniform(1, 2))

    driver.get("https://new.land.naver.com/offices?ms=37.7281206,126.7344198,17&realtorId=k9222580")
    time.sleep(random.uniform(2, 3))
    
    driver.get("https://new.land.naver.com/offices?ms=37.7281206,126.7344198,17&realtorId=k9222580")
    time.sleep(random.uniform(2, 3))
    
    WebDriverWait(driver, 20).until(lambda d: d.execute_script("return document.readyState") == "complete")
    time.sleep(random.uniform(1, 2))
        
    # 리스트 준비 대기
    wait_for_list_ready(driver, timeout=25)

    results = click_all_item_links(driver, pause=1.0)   # 끝까지
    print(f"총 {len(results)}건 수집")

    driver.quit()

    return results

def get_office_info_api(article_no):
    url = f"https://new.land.naver.com/api/articles/{article_no}"
    
    headers = {
        "User-Agent": USER_AGENT,
        "Referer": f"https://new.land.naver.com/offices?articleNo={article_no}",
        "Accept": "application/json",
        "Accept-Language": "ko-KR,ko;q=0.9",
    }

    try:
        time.sleep(random.uniform(1.5, 3.5))  # ✅ 요청 간 딜레이
        response = requests.get(url, headers=headers)
        response.raise_for_status()

        data = response.json()
        print(f"\n📦 매물번호: {article_no}")
        print("📋 주요 정보:")
        print("-" * 30)
        for key, value in data.items():
            print(f"{key}: {value}")
        return data

    except requests.exceptions.RequestException as e:
        print(f"[❌ 오류] 매물 {article_no} 조회 실패: {e}")
        return None
    
# 메인 함수
def main():
    try:
        baikukFunction.retry_function(crawl_all_articles)
        # get_office_info_api("2541370193")
    except Exception as e:
        print(f"프로그램 실행 중 오류가 발생했습니다: {e}")
    finally:
        print("프로그램이 종료되었습니다. 창을 닫으려면 Enter 키를 누르세요...") # 프로그램이 종료되기 전에 사용자 입력을 기다림

if __name__ == '__main__':
    main()
