# pip install selenium chromedriver-autoinstaller random-user-agent pywin32 pyautogui gspread google-auth google-api-python-client oauth2client pandas gspread-dataframe openpyxl numpy openai tqdm supabase beautifulsoup4 webdriver-manager

# 개인변수 설정
down_path = "D:/Users/ymg16/Downloads" # 집
current_directory = "C:/Users/ymg16/Admanager_home" # 집
# maemuljaing_key = "1Kk_7pso3pSr6qBfovE-PARJifHcupxvQLYKTtQhfSNk" # 개발용 매물장 키

# down_path = "C:/Users/ymg16/Downloads" # 노트북
# current_directory = "C:/Users/ymg16/Admanager" # 노트북
maemuljaing_key = "1dNowK6Dur4deOHRpuJRV0YgtIx8f4T2tl_z2doL4E08" # 매물장 키

# down_path = "C:/python_program/Downloads" # 회사
# current_directory = "C:/python_program/Admanager" # 회사
kakao_api_key = "3b0334d7d0fff4867703da0fbe5312be" # 이슬
KAKAO_API_KEY2 = "2bc87e55e54855e459d1f38d6ed96a3b" # 명근
kakao_api_keys = [
    "3b0334d7d0fff4867703da0fbe5312be", # 이슬
    "2bc87e55e54855e459d1f38d6ed96a3b" # 명근
]
public_data_key = "C86J0IyBbVdojhuSeSb91PA1ZHDEb8KkYnh/xwIITC1rp+bwcHu25YWSsvzXTNGWs1Xs7Y5s5tIlFz7hDoKJDQ==" # 공공데이터 api 키
json_site = f'{current_directory}/baikuk-7e4a1-e78766ddb582.json' #json파일 경로

SUPABASE_URL = "https://sfinbtiqlfnaaarziixu.supabase.co"
SUPABASE_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNmaW5idGlxbGZuYWFhcnppaXh1Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1MjUwOTE2MSwiZXhwIjoyMDY4MDg1MTYxfQ.EsvPxO4Ig35UOUdH7Yn_qmwIKje5A51p_QDFWlu9ntc"
SUPABASE_API_SURVIVCE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNmaW5idGlxbGZuYWFhcnppaXh1Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1MjUwOTE2MSwiZXhwIjoyMDY4MDg1MTYxfQ.EsvPxO4Ig35UOUdH7Yn_qmwIKje5A51p_QDFWlu9ntc"
SUPABASE_TABLE_BAIKUKDBTEST = "baikukdbtest"
SUPABASE_TABLE_BUILDING_INFO = "building_info"
SUPABASE_TABLE_WORK_LOG = "work_log"
SUPABASE_TABLE_only_lat_lng = "only_lat_lng"

ad_crawling_sheet_keys = [
    "1iZhHPPHA2Kqywyrkpnt_EjIa26QlmB_Y5GuBSp86nMY", # 광고조회_유명근
    "1MgctWGNF8_1MH3LxBPxb3w05FkN01QbVOPALzncnYhs", # 광고조회_조인호
    "1tZTSXZGNbQYuzYdzSBZIyl1FNov5acsNZqxdLBZpJ3Y", # 광고조회_이승윤
    "1_t-0XxOqWITt1pbibhAa-OhsxnoD3233ZBhX4GksjqM", # 광고조회_백은혜
    "1dt_kwQuBhiNVpD2NBApfwbcSpsZ9VmwW7Z62SCMCbGs", # 광고조회_김덕상
]

statistics = "1SOGf17OUyb8B-ZZ65I2tcWXbgPhs-v28tFB96kIUsvA" # 통계시트
baikuk_import = "1u1qPeXBOVxTV7E2-S_nhuz9xVkTmuESDeFl427rtS_w" # 백억중요
store_info = "14WucgbH7m58JMZu1dPyaaduYNGgMP17Q9ufhzU8gzWk" # 입점현황

drive_data_folder_id = "1J_sw9z2QvKJbvg40Rr92owuXsoeiSgCz" #구글드라이브 데이터
drive_data_folder_id_2025 = "1i0mEPpRsV_9gg2O7Sp9HngxwqYNW4XZm" # 구글드라이브 데이터_2025

maemulLog_data_folder_id = "1cxpd_H7WD_8Ccd_JTXxqYWUN7i5sO-g1" #물건번호로그 폴더
cog_sheet_key = "100p__XPZgk7XQpeM7KHZUX64jEWGZ44bxUoOqNA4L-4" # 백억장부 스프레드시트 키


ad_sheet_key = "1b0rL8KzjpZpnCExFANrOohjxFUXds8ZHrP7cIfcItLw" # 2_백억광고관리(크롤링) 스프레드시트 키
ad_sheet_key2 = "12CfmNNRVl4BSRhUnnWSwcMJJ-9E4zIErWGjujgkur7o" # 백억광고 스프레드시트 키


ad_auto_sheet_key = "1NJdCazsd-8cbrxusae9soVmxNrmB2LC6Rx2KVhOTxyo" # 3_자동화 스프레드시트
lat_lng_key = "1G_ZxKlJvInkudmdKcD0fHOwq3jvlkrBzlyfXSYl4j5o" # 위도, 경도 스프레드시트
bugisa_id = "ymg1633@gmail.com"
bugisa_pw = "gksrnr231!"

tel_num = "031-943-2834"


supabase_url = "https://kuxgjshdxiuzgaaaeoiw.supabase.co"
supabase_key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt1eGdqc2hkeGl1emdhYWFlb2l3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA1MDI3NzMsImV4cCI6MjA2NjA3ODc3M30.B4unXkRfKsA9Y9XVnQtbyez4u959sT1gfG00ZJia-2w"
openai_key = "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" 


# 제외할 단어 문자열 (공백 포함 제거된 형태로 구성)
exclude_industry_words_raw = "각종, 등, 특징, :, 다양한업종, 업종, 프랜차이즈, 다양한, 프렌차이즈, 추천, 중심상가, 해오름마을, 대로변, 핵심입지, 신축, 가능, 양도양수, 및, 자유업종, 관련, 판매, 강력추천, 모든업종, 추천매물, 소사무실, 단독, 강추, 기타, 스크린, 활용가능, 편의시설, 관련업, 일반판매점, 타업종, 업종자유, 자유업가능, 다양한업종가능, 다용도점포, 현업종, 또는, 업종무관, 다용도, 좋은, 등등, 그대로, 활용, 자유업등, 점포가능, 유명, 현, 인수, 업, 근린생활시설, 병, 센터, 투자, 기타외식업, 테이크, 승계, 클릭시, 사진O, 1층, 내, 상가, 테라스, 추첨, 기타외식, 중소, 일반, 도로변, 대형면적, 특징:, 매물, 단지내상가, 자유, 시설, 특화, 백억, 부동산의, 약속, 양도, 양수, 업무시설, 각종판매점, 어느업종이든, 가능합니다, 자유업잌, 소호, 업종제한없습니다, 기타판매업, 문의환영, 프렌차이즈매장, 노출좋은, 문의, 다방면, 아파트, 단지, 사용가능, 양수도, 프렌차이즈창업, 공간활용, 가능한, 업종가능, 중, 기타판매점, 운동시, 프렌차이등, 학, 종류업종, 무관, 제외, 판매시설, 동일업종제한, 자유로운, 마사집샵, 습식주방O, 열린건물, 화장실, 받으실분, 치킨집양도양수, 교습, 생산시설, 음식좀, 뷰피, 업종관계, 無, 화장품업잌, 인가센터, 스몰, 마샤지, 기존, 인수환영, 전, 전력사용, 많은, 양식&amp, 자유업종가능, 9, 시설완비, 매출, 코너상가, 고방, 다향안, &amp, 플레업종, 어떤, 업종이든, 제2종근린생활시설, 이외, 겸, 소형점포, 인수가능, 현브랜드, 다양한업종추천, 소음가능한, 전수창업, 대여, 프랜차이져, 프리미엄, 사우실, 양도하실분, 2종근린생활시설, 1종, 커피&amp, 인수받아서, 운영, 타업종가능, 이짜까야, 기타주점, 조리읍, 1층상가, 광고효과, 좋은자리, 용품, 항아리상권, 문발IC집입용이, 높이11, 운영중, 사진O문발동, 상가주택, 매물입니다, 몸만, 오셔서, 바로, 영업하실분, 근생시설, 영업인수추천, 노출, 월세, 저렴, 복층구조, 아웃, 대형평수로, 입점가능, 렌트프리, 협의가능, 매출확보, 금릉역, 자리, 현재, 성업중인, 유동인구, 굿, 사용가능한, 접근성, 각, 분위기, 연습실잌, 치킨집프, 관련업종, 자유업"

# 문자열을 줄바꿈 기준으로 나눠서 리스트로 변환
exclude_industry_words = set(
    word.strip() for word in exclude_industry_words_raw.replace('\n', ',').split(',') if word.strip()
)


# 완전히 일치하는 문장을 제외할 리스트

exclude_exact_phrases = set(["-", ])