from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import chromedriver_autoinstaller
import time
from random_user_agent.user_agent import UserAgent
from random_user_agent.params import SoftwareName, OperatingSystem
import win32gui
import pyautogui
import os
from datetime import datetime, timedelta
import gspread
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from oauth2client.service_account import ServiceAccountCredentials
import pandas as pd
from gspread_dataframe import get_as_dataframe
from gspread_dataframe import set_with_dataframe
import re
import signal
import zipfile
import numpy as np
import var
import baikukFunction
from gspread.exceptions import APIError
from collections import Counter
from supabase import create_client
import chardet
import set_baikukdb
import lxml
import xlrd
import html5lib


# 초기 입력값: 날짜형식
today_Ymd = datetime.today().strftime('%Y%m%d')
today_Ymd2 = datetime.today().strftime('%Y-%m-%d')
today_ymd = datetime.today().strftime('%Y%m%d')
today_Y_m_d = datetime.today().strftime('%Y_%m_%d')

# Google API 인증 설정
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name(var.json_site, scope)
client = gspread.authorize(creds)

# 기본 설정
USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36')
API_BASE_URL = 'https://new.land.naver.com'

# OAuth 2.0 인증 파일 경로 설정 (구글드라이브 관련)
scopes = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive'
]
credentials = Credentials.from_service_account_file(f'{var.json_site}', scopes=scopes)

# Google Sheets 및 Drive API 초기화
gc = gspread.authorize(credentials)
drive_service = build('drive', 'v3', credentials=credentials)

# 크롬 드라이버 자동 설치
chromedriver_autoinstaller.install()

# 크롬 옵션 설정
chrome_options = Options()
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=http://homesdid.co.kr/mmc/")
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=https://baikuk.com/") 
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=http://homesdid.co.kr/mmc/") 

pyautogui.FAILSAFE = False

# 프로그램 종료 플래그
should_terminate = False

# SIGINT 핸들러 정의
def signal_handler(sig, frame):
    global should_terminate
    print('Ctrl+C 입력됨. 프로그램을 중지하고 데이터를 저장합니다...')
    should_terminate = True

# SIGINT 핸들러 등록
signal.signal(signal.SIGINT, signal_handler)

# 부기사에서 다운로드, 백억장부-원본에 업데이트

def unzip_file(zip_path, extract_to):
    # zip 파일 열기
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        # 압축을 풀 경로가 존재하지 않으면 생성
        if not os.path.exists(extract_to):
            os.makedirs(extract_to)
        # 압축 해제
        zip_ref.extractall(extract_to)
        print(f"'{zip_path}' 파일이 '{extract_to}' 경로에 성공적으로 압축 해제되었습니다.")

def down_bugisa(user_id, user_pw):
    # 브라우저 실행
    browser = webdriver.Chrome(options=chrome_options)
    browser.maximize_window()
    browser.implicitly_wait(10)
    pyautogui.sleep(2)
    browser.implicitly_wait(10)
    pyautogui.sleep(2)

    # 로그인 페이지로 이동
    browser.get("https://baikuk.com/map")
    browser.implicitly_wait(10)
    pyautogui.sleep(5)
    browser.find_element(By.XPATH, '//*[@id="mapWrapper"]/div[6]/div[1]/div/div[2]').click()
    browser.implicitly_wait(10)
    pyautogui.sleep(1)
    

    # 로그인 처리 
    browser.find_element(By.XPATH, '//*[@id="email"]').send_keys(user_id)
    browser.implicitly_wait(10)
    pyautogui.sleep(0.5)
    browser.find_element(By.XPATH, '//*[@id="password"]').send_keys(user_pw)
    browser.implicitly_wait(10)
    pyautogui.sleep(0.5) 
    browser.find_element(By.XPATH, '//*[@id="form_signin"]/button').click()
    browser.implicitly_wait(10)
    pyautogui.sleep(5)

    # 다운로드 페이지로 이동
    browser.get("https://baikuk.com/admin")
    browser.implicitly_wait(10)
    element = WebDriverWait(browser, 10).until(
        EC.element_to_be_clickable((By.XPATH, '//*[@id="admin_wrap"]/div[1]/nav/ul/li[2]/a/span[2]'))
    )
    pyautogui.sleep(3)
    element.click()
    browser.implicitly_wait(10)
    pyautogui.sleep(3)
    element = WebDriverWait(browser, 10).until(
        EC.element_to_be_clickable((By.XPATH, '//*[@id="admin_wrap"]/div[1]/nav/ul/li[2]/ul/li[1]/span'))
    )
    element.click()
    browser.implicitly_wait(10)
    pyautogui.sleep(10)

    # 오늘 날짜 가져오기
    today_str = datetime.today().strftime('%y%m%d')

    # 엑셀 파일 경로 생성
    file_paths = [
        f"{var.down_path}/매물목록({datetime.today().strftime('%y%m%d')}).zip",
        f'{var.down_path}/{today_str}-1.xlsx',
        f'{var.down_path}/{today_str}-2.xlsx',
        f'{var.down_path}/{today_str}-3.xlsx',
        f'{var.down_path}/{today_str}-4.xlsx',
        f'{var.down_path}/{today_str}-5.xlsx',
        f'{var.down_path}/{today_str}-6.xlsx'
    ]

    # 기존 파일 삭제
    for file_path in file_paths:
        if os.path.exists(file_path):
            os.remove(file_path)
            print(f"{file_path} 파일이 삭제되었습니다.")
    
    # 파일 경로 및 압축을 풀 폴더 경로 지정
    zip_file_path = f'{var.down_path}/매물목록({today_str}).zip'

    # 다운로드 버튼 클릭
    browser.find_element(By.XPATH, '/html/body/div[2]/div[3]/section/div/div[1]/div[2]/div[2]').click()
    while not os.path.exists(zip_file_path):
        browser.implicitly_wait(10)
        pyautogui.sleep(7)

    pyautogui.sleep(5)


    ##################### 업무일지도 다운로드 #$################
    
    # 🌐 페이지 이동
    browser.get("https://baikuk.com/admin_comment?page=1&types=&member_id=&type=&keyword=")
    browser.implicitly_wait(10)
    pyautogui.sleep(5)

    # 📅 오늘 날짜 문자열 (예: '0727')
    today_str_work_log = datetime.now().strftime("%m%d")

    # 📄 예상 파일명
    filename_work_log = f"업무일지목록-{today_str_work_log}.xls"
    file_path_work_log = os.path.join(var.down_path, filename_work_log)

    # 🗑 기존 파일 삭제
    if os.path.exists(file_path_work_log):
        print(f"📄 기존 파일 삭제: {file_path_work_log}")
        os.remove(file_path_work_log)

    # 📥 업무일지 다운로드 버튼 클릭
    browser.find_element(By.XPATH, '//*[@id="searchForm"]/div[1]/a/i').click()
    pyautogui.sleep(5)

    #############################################################

    # 브라우저 닫기
    browser.quit()
    print(f"{file_paths[0]} 다운로드가 완료되었습니다.")

    # 압축 풀기 함수 실행
    unzip_file(zip_file_path, var.down_path)

def sum_bugisa():
    print("******* sum_bugisa() *******")
    # 빈 데이터프레임 생성
    combined_df = pd.DataFrame()
    
    # 오늘 날짜 가져오기
    today_str = datetime.today().strftime('%y%m%d')
    today_str2 = datetime.today().strftime('%Y%m%d')
    
    #엑셀 파일 경로 생성
    file_paths = [
        f'{var.down_path}/{today_str}-1.xlsx',
        f'{var.down_path}/{today_str}-2.xlsx',
        f'{var.down_path}/{today_str}-3.xlsx',
        f'{var.down_path}/{today_str}-4.xlsx',
        f'{var.down_path}/{today_str}-5.xlsx',
        f'{var.down_path}/{today_str}-6.xlsx',
        f'{var.down_path}/{today_str}-7.xlsx'
    ]

    # 각 엑셀 파일의 첫 번째 시트를 읽어서 데이터프레임에 추가
    for file in file_paths:
        try:
            df = pd.read_excel(file, engine='openpyxl')
            combined_df = pd.concat([combined_df, df], ignore_index=True)
        except FileNotFoundError:
            print(f"파일을 찾을 수 없습니다: {file}")
            continue

    
    ###### 가독성 위해 제목 수정
    # '(' 앞에 공백 추가
    combined_df['제목'] = combined_df['제목'].str.replace(r'\(', ' (', regex=True)
    # ','를 ', '로 변환 (쉼표 뒤에 공백 추가)
    combined_df['제목'] = combined_df['제목'].str.replace(r',+', ', ', regex=True)
    # 연속된 공백을 하나의 공백으로 변환
    combined_df['제목'] = combined_df['제목'].str.replace(r'\s+', ' ', regex=True)
    
    # ','를 ', '로 변환 (쉼표 뒤에 공백 추가)
    combined_df['호수정보'] = combined_df['호수정보'].str.replace(r',+', ', ', regex=True)
    # 연속된 공백을 하나의 공백으로 변환
    combined_df['호수정보'] = combined_df['호수정보'].str.replace(r'\s+', ' ', regex=True)

    # 부기사 원본데이터 백업
    output_file = f'combined_bugisa_{today_str2}'
    spreadsheet_combined_bugisa = baikukFunction.create_backup_spreadsheet(output_file)
    baikukFunction.save_dataframe_to_sheet(spreadsheet_combined_bugisa.id, combined_df, "기본시트")
    
    return combined_df

# 물건번호호출로그 6개월치 가져와서 하나의 데이터프레임으로 반환
def load_recent_6_months_maemullog():
    print("📦 최근 6개월 '물건번호로그' 데이터를 불러옵니다...")

    current = datetime.now()
    current_month = current.month
    current_year = current.year

    # 최근 6개월의 (연도, 월) 리스트 생성
    recent_months = []
    for i in range(6):
        month = current_month - i
        year = current_year
        if month <= 0:
            month += 12
            year -= 1
        recent_months.append((year, str(month)))  # 시트 이름은 문자열

    df_list = []

    for year, month in recent_months:
        file_name = f"물건번호로그_{year}"
        try:
            # 🔹 파일 ID 가져오기
            spreadsheet_id = baikukFunction.get_spreadsheet_id_with_retries(
                baikukFunction.get_spreadsheet_id_by_name,
                var.maemulLog_data_folder_id,
                file_name
            )

            # 🔹 스프레드시트 열기
            spreadsheet = baikukFunction.open_spreadsheet_with_retries(client, spreadsheet_id)

            # 🔹 월 시트 열기 (ex. '1', '2', ..., '12')
            worksheet = spreadsheet.worksheet(month)
            data = worksheet.get_all_values()
            df = pd.DataFrame(data[1:], columns=data[0])
            df_list.append(df)
            print(f"✅ '{file_name}' 시트 '{month}' 로드 완료")
        except Exception as e:
            print(f"⚠️ '{file_name}' 시트 '{month}' 로드 실패: {e}")

    if not df_list:
        raise ValueError("최근 6개월 시트를 불러오지 못했습니다.")

    # 병합
    df_maemullog = pd.concat(df_list, ignore_index=True)

    # 필요한 열만 필터링 (안전하게)
    expected_columns = ['매물번호', '현재날짜', '입력자']
    df_maemullog = df_maemullog[[col for col in expected_columns if col in df_maemullog.columns]]

    return df_maemullog

def bugisa_for_sheet():
    print("********* bugisa_for_sheet ***********")
    # 현재 날짜와 하루 전 날짜 설정
    current_date = datetime.now()

    # 파일명 생성
    filename_bugisa = f'combined_bugisa_{current_date.strftime("%Y%m%d")}'

    # 스프레드시트 ID 가져오기 시도
    spreadsheet_id_bugisa = baikukFunction.get_spreadsheet_id_with_retries(
        baikukFunction.get_spreadsheet_id_by_name,
        var.drive_data_folder_id,
        filename_bugisa
    )
    spreadsheet_bugisa = baikukFunction.open_spreadsheet_with_retries(
        client,
        spreadsheet_id_bugisa
    )
    worksheet_bugisa = spreadsheet_bugisa.get_worksheet(0)
    data = worksheet_bugisa.get_all_values()
    bugisa_df = pd.DataFrame(data[1:], columns=data[0])  # 첫 번째 행을 컬럼 이름으로 사용
    # 수치형으로 변환할 열들을 명시
    numeric_columns = ['전용면적 (평)', '보증금(만원)', '월세(만원)', '권리금(만원)', '매매가(만원)', 
                       '총월세 보증금(만원)', '총월세', '전용면적 (㎡)']

    # 각 열에 대해 수치형으로 변환, 변환 불가 값은 0으로 설정
    for col in numeric_columns:
        bugisa_df[col] = bugisa_df[col].astype(str).str.replace(',', '')  # 콤마 제거
        bugisa_df[col] = pd.to_numeric(bugisa_df[col], errors='coerce').fillna(0)

    # '지상,지하 구분' 값에 불필요한 공백을 제거하고 대소문자를 통일하여 비교
    bugisa_df['해당층'] = bugisa_df.apply(
        lambda row: f"-{row['해당층']}" if row['지상,지하 구분'].strip().lower() == '지하' and not str(row['해당층']).startswith('-') else row['해당층'], 
        axis=1
    )

    # .loc[]를 사용하여 값을 수정
    bugisa_df.loc[:, '링크'] = 'https://baikuk.com/item/view/' + bugisa_df['매물번호'].astype(str)
    # 숫자 또는 숫자-숫자가 포함된 앞부분을 추출 (입력값을 문자열로 변환하여 오류 방지)
    bugisa_df['상세주소'] = bugisa_df['상세주소'].astype(str)
    bugisa_df['추출된주소'] = bugisa_df['상세주소'].str.extract(r'(^.*?\s*(\d+-\d+|\d+))', expand=False)[0]
    # NaN 값이 발생하면 기존 값 유지
    bugisa_df['상세주소'] = bugisa_df['추출된주소'].combine_first(bugisa_df['상세주소'])
    # 임시 컬럼 삭제
    bugisa_df.drop(columns=['추출된주소'], inplace=True)

    bugisa_df.loc[:, '지번주소'] = bugisa_df['시/도'] + ' ' + bugisa_df['구/군'] + ' ' + bugisa_df['동/읍/면'] + ' ' + bugisa_df['상세주소']

    # 0으로 나누는 상황에서 값을 0으로 표시
    bugisa_df['평당임대료'] = np.where(bugisa_df['전용면적 (평)'] == 0, 0, bugisa_df['월세(만원)'] / bugisa_df['전용면적 (평)'])
    bugisa_df['평당매매가'] = np.where(bugisa_df['전용면적 (평)'] == 0, 0, bugisa_df['매매가(만원)'] / bugisa_df['전용면적 (평)'])
    
    # 수익률 계산 (0으로 나누는 경우 수익률은 0으로 처리)
    bugisa_df['수익률'] = np.where((bugisa_df['매매가(만원)'] - bugisa_df['총월세 보증금(만원)']) == 0, 0, 
                                    (bugisa_df['총월세'] * 12) / (bugisa_df['매매가(만원)'] - bugisa_df['총월세 보증금(만원)']))

    # 결측값을 0으로 채우기
    bugisa_df = bugisa_df.fillna(0)

    # '건물명'이 비어있거나 '-'이면 '동명' 값을 저장
    bugisa_df['건물명'] = bugisa_df['건물명'].replace({'-': None, '': None, '0': None, 0: None}).fillna(bugisa_df['동명'])

    # '업종' 열 생성
    bugisa_df['업종'] = bugisa_df['상세정보'].apply(baikukFunction.extract_business_type)

    # 적용
    bugisa_df['특징'] = bugisa_df['상세정보'].apply(baikukFunction.extract_features)

    # 추천횟수
    df_maemullog = load_recent_6_months_maemullog()
    # 매물번호별 추천 횟수 계산 (df_maemullog 기준)
    recommend_counts = df_maemullog['매물번호'].value_counts()

    # bugisa_df에 추천 횟수 매핑
    bugisa_df['추천'] = bugisa_df['매물번호'].astype(str).map(recommend_counts).fillna(0).astype(int)

    # 선택한 열만 유지
    columns_to_select = ['매물번호', '링크', '담당자명', '거래완료 여부', '대분류 1차', '거래유형', '지번주소', '건물명', 
                         '호수정보', '해당층', '매물명', '전용면적 (평)', '보증금(만원)', '월세(만원)', 
                         '평당임대료', '권리금(만원)', '매매가(만원)', '평당매매가', '총월세 보증금(만원)', 
                         '총월세', '수익률', '전용면적 (㎡)', '전체층', '업종', '특징', '추천']
    
    bugisa_df_sorted = bugisa_df[columns_to_select]
    # 전체 열 이름을 리스트로 지정하여 변경
    new_columns = ['매물번호', '링크', '담당자명', '거래완료 여부', '대분류 1차', '거래유형', '상세주소', '건물명', 
                '호수정보', '층', '제목', '면적(평)', '보증금', '월세', 
                '평당임대료', '권리금', '매매가', '평당매매가', '총월세 보증금', 
                '총월세', '수익률', '전용면적 (㎡)', '전체층', '업종', '특징', '추천']
    bugisa_df_sorted.columns = new_columns
    df = bugisa_df_sorted

    print(f'백억장부 원본 시트에 키 추가중...')    
    # 필요한 열이 모두 존재하는지 확인
    required_columns = ['상세주소', '층', '전용면적 (㎡)', '보증금', '월세']
    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"데이터프레임에 '{col}' 열이 없습니다.")

    # 전용면적이 숫자인지 확인하고, 문자열인 경우 float로 변환
    df['전용면적 (㎡)'] = pd.to_numeric(df['전용면적 (㎡)'], errors='coerce')

    # '상세주소'를 기반으로 '지번주소'를 처리
    df['지번주소'] = df['상세주소'].apply(
        lambda x: (
            baikukFunction.extract_representative_address(x)
            if pd.notna(x)
            else x
        )
    )

    # 새로운 열을 추가 (각 열을 문자열로 변환 후 결합)
    df['키'] = df.apply(
        lambda row: (
            f"{row['거래유형'].replace(' ', '_') if pd.notna(row['거래유형']) else 'N/A'}_"
            f"{str(row['지번주소']).replace(' ', '_').replace('-', '_') if pd.notna(row['지번주소']) else 'N/A'}_"
            f"{row['층'] if pd.notna(row['층']) else 'N/A'}_"
            f"{round(row['전용면적 (㎡)'],-2) if pd.notna(row['전용면적 (㎡)']) else 'N/A'}_"
            f"{row['보증금'] if pd.notna(row['보증금']) else 'N/A'}_"
            f"{row['월세'] if pd.notna(row['월세']) else 'N/A'}_"
        ),
        axis=1
    )

    # 전체 열 순서 변경
    new_order = ['매물번호', '업종', '제목', '링크', '거래완료 여부', '대분류 1차', '거래유형', '상세주소', '건물명', '호수정보', '층', 
                 '전용면적 (㎡)', '면적(평)', '보증금', '월세', '평당임대료', '권리금', '특징', '추천', '매매가', '평당매매가', '총월세 보증금', '총월세', '수익률',
                 '담당자명', '전체층', '키']
    df = df[new_order]

    return df

def update_bugisa(df):
    print("****** update_bugisa ********")
    spreadsheet = baikukFunction.open_spreadsheet_with_retries(
            client,
            var.cog_sheet_key
        )
    worksheet_log = spreadsheet.worksheet("업데이트로그")
    worksheet_log.update(range_name='a2', values=[["업데이트중..."]])

    df_for_maemuljang = df.copy()
    df_for_maemuljang['주소'] = df_for_maemuljang['상세주소']
    df_for_maemuljang['상세주소'] = df_for_maemuljang['상세주소'].apply(baikukFunction.get_last_two_words)
    # 데이터프레임의 각 행에 update_address_with_floor 함수를 적용합니다.
    df_for_maemuljang['상세주소'] = df_for_maemuljang.apply(baikukFunction.update_address_with_floor, axis=1)
    # '-' 값을 0으로 바꾸기
    df_for_maemuljang['층'] = df_for_maemuljang['층'].replace('-', 0)
    df_for_maemuljang['층'] = df_for_maemuljang.apply(baikukFunction.adjust_floor, axis=1) # '지하' 포함 시 음수 처리
    df_for_maemuljang['층'] = pd.to_numeric(df_for_maemuljang['층'], errors='coerce')

    # 원하는 열 이름 순서대로 리스트를 정의합니다.
    columns_order = ['링크', '매물번호', '업종', '제목', '주소', '층', '면적(평)', '보증금', '월세', '권리금', '특징', '추천', '매매가', '총월세 보증금', '총월세', '수익률', '거래완료 여부', '상세주소']
    df_maemuljang = df_for_maemuljang[columns_order]

    ########### 평당월세, 평당매매가 열 추가 #################

    # 숫자 변환
    df_maemuljang['월세'] = pd.to_numeric(df_maemuljang['월세'], errors='coerce')
    df_maemuljang['매매가'] = pd.to_numeric(df_maemuljang['매매가'], errors='coerce')
    df_maemuljang['면적(평)'] = pd.to_numeric(df_maemuljang['면적(평)'], errors='coerce')

    # '평월세' 계산 (계산 불가능한 경우 0으로)
    df_maemuljang['평월세'] = df_maemuljang.apply(
        lambda row: round(row['월세'] / row['면적(평)'], 1)
        if pd.notnull(row['월세']) and pd.notnull(row['면적(평)']) and row['면적(평)'] != 0
        else 0,
        axis=1
    )

    # '평월세' 열 삽입
    월세_index = df_maemuljang.columns.get_loc('월세')
    columns = list(df_maemuljang.columns)
    if '평월세' in columns:
        columns.remove('평월세')
    columns.insert(월세_index + 1, '평월세')
    df_maemuljang = df_maemuljang[columns]

    # '평매매가' 계산 (계산 불가능한 경우 0으로)
    df_maemuljang['평매매가'] = df_maemuljang.apply(
        lambda row: round(row['매매가'] / row['면적(평)'], 0)
        if pd.notnull(row['매매가']) and pd.notnull(row['면적(평)']) and row['면적(평)'] != 0
        else 0,
        axis=1
    )

    # '평매매가' 열 삽입
    매매가_index = df_maemuljang.columns.get_loc('매매가')
    columns = list(df_maemuljang.columns)
    if '평매매가' in columns:
        columns.remove('평매매가')
    columns.insert(매매가_index + 1, '평매매가')
    df_maemuljang = df_maemuljang[columns]
    
    df_imDae = df_maemuljang.copy()
    desired_columns = ['매물번호', '제목', '상세주소', '면적(평)', '보증금', '월세', '권리금']
    df_imDae = df_imDae[desired_columns]
    df_imDae.columns = ['매물번호', '제목', '상세주소', '면적', '보증금', '월세', '권리금']
    
    df_maeMae = df_maemuljang.copy()
    desired_columns = ['매물번호', '제목', '상세주소', '면적(평)', '매매가', '총월세 보증금', '총월세', '수익률', '평매매가']
    df_maeMae = df_maeMae[desired_columns]
    df_maeMae.columns = ['매물번호', '제목', '상세주소', '면적', '매매가', '보증금', '월세', '수익률', '평당가']
    

    # 1. '업종' 열의 모든 데이터를 하나의 문자열로 합침
    text = ' '.join(df['업종'].dropna().astype(str))

    # 2. 정규표현식으로 단어 추출: 공백, '/', 줄바꿈, '.', ',', '(', ')' 등으로 분리
    words = re.split(r"[\/\s\.,;\n()\[\]\"\'\-·]+", text)

    # 3. 빈 문자열 제거
    words = [word.strip() for word in words if word.strip()]

    # 4. 제외 단어 제거
    filtered_words = [word for word in words if word not in var.exclude_industry_words]

    # 5. 단어 빈도수 계산 및 정렬
    word_counts = Counter(filtered_words)
    word_count_list = word_counts.most_common()  # 이미 등장 횟수 기준 내림차순 정렬됨

    # 1. '특징' 컬럼 텍스트 정제 및 병합
    feature_text = ' '.join(df['특징'].dropna().astype(str))
    feature_text = re.sub(r"[◆✔️●★:■|◈]", "", feature_text)  # 기호 제거

    # 2. 단어 단위 분리
    feature_words = re.split(r"[\/\s\.,;\n()\[\]\"\'\-·]+", feature_text)

    # 3. 공백 제거 및 제외 단어 필터링
    feature_words = [word.strip() for word in feature_words if word.strip()]
    feature_words = [
        word for word in feature_words
        if word not in var.exclude_exact_phrases
    ]

    # 4. 단어 빈도 계산
    feature_word_counts = Counter(feature_words)
    feature_word_list = feature_word_counts.most_common()



    ####################################################


    data = [df_maemuljang.columns.tolist()] + df_maemuljang.values.tolist()  # ✅ 1행에 열 제목 추가
    data_imDae = [df_imDae.columns.tolist()] + df_imDae.values.tolist()  # ✅ 1행에 열 제목 추가
    data_maeMae = [df_maeMae.columns.tolist()] + df_maeMae.values.tolist()  # ✅ 1행에 열 제목 추가

    # 최대 재시도 횟수 설정
    MAX_RETRIES = 3
    attempt = 0
    success = False

    while attempt < MAX_RETRIES and not success:
        try:
            # Google Sheets 스프레드시트에 접근
            spreadsheet = baikukFunction.open_spreadsheet_with_retries(
                client,
                var.maemuljaing_key
            )
            # === 기본시트 업데이트 ===
            worksheet_default = spreadsheet.worksheet("기본시트")
            worksheet_default.update('A1', data)

            rows_in_sheet = len(worksheet_default.get_all_values())
            rows_in_df = len(data) + 1
            if rows_in_sheet > rows_in_df:
                worksheet_default.delete_rows(rows_in_df + 1, rows_in_sheet)

            # === 임대 시트 업데이트 ===
            worksheet_imdae = spreadsheet.worksheet("임대")
            worksheet_imdae.update('A1', data_imDae)

            rows_in_sheet_imdae = len(worksheet_imdae.get_all_values())
            rows_in_df_imdae = len(data_imDae) + 1
            if rows_in_sheet_imdae > rows_in_df_imdae:
                worksheet_imdae.delete_rows(rows_in_df_imdae + 1, rows_in_sheet_imdae)

            # === 매매 시트 업데이트 ===
            worksheet_maemae = spreadsheet.worksheet("매매")
            worksheet_maemae.update('A1', data_maeMae)

            rows_in_sheet_maemae = len(worksheet_maemae.get_all_values())
            rows_in_df_maemae = len(data_maeMae) + 1
            if rows_in_sheet_maemae > rows_in_df_maemae:
                worksheet_maemae.delete_rows(rows_in_df_maemae + 1, rows_in_sheet_maemae)

            # === 업종 시트 업데이트 ===
            worksheet_upjong = spreadsheet.worksheet("단어사용빈도")

            # 업종 빈도 데이터 (A, B열)
            upjong_words = [("업종", "사용횟수")] + word_count_list

            # 특징 빈도 데이터 (C, D열)
            feature_words = [("특징", "특징사용횟수")] + feature_word_list

            # 두 데이터를 좌우로 붙이기 (행 개수 맞추기)
            max_len = max(len(upjong_words), len(feature_words))
            while len(upjong_words) < max_len:
                upjong_words.append(("", ""))
            while len(feature_words) < max_len:
                feature_words.append(("", ""))

            # 행 단위로 붙이기
            combined_data = [
                upjong_words[i] + feature_words[i]
                for i in range(max_len)
            ]

            # 업데이트
            worksheet_upjong.update('A1', combined_data)

            # 기존 행 초과 시 삭제
            rows_in_sheet_upjong = len(worksheet_upjong.get_all_values())
            if rows_in_sheet_upjong > len(combined_data):
                worksheet_upjong.delete_rows(len(combined_data) + 1, rows_in_sheet_upjong)



            # 성공적으로 업데이트 완료
            success = True
            print(f'{spreadsheet.title} 스프레드시트의 매물장이 업데이트되었습니다.')

        except APIError as e:
            attempt += 1
            print(f"API 오류 발생: {e}. {attempt}번째 시도 실패. 3초 후 재시도합니다.")
            time.sleep(3)

    if not success:
        print(f'{var.maemuljaing_key} 스프레드시트 업데이트에 실패했습니다. {MAX_RETRIES}번 시도 후 포기.') 

    # 백업
    filename = f'원본_py_{datetime.now().strftime("%Y%m%d")}'
    spreadsheet_bugisa = baikukFunction.create_backup_spreadsheet(filename)
    baikukFunction.save_dataframe_to_sheet(spreadsheet_bugisa.id, df,"기본시트")

    # 업데이트 시간 표시
    now = datetime.now()  # 현재 날짜와 시간 가져오기
    weekdays = ['월', '화', '수', '목', '금', '토', '일']  # 요일 리스트 (0: 월요일, 6: 일요일)
    formatted_time = f"{now.month}/{now.day}({weekdays[now.weekday()]}) {now.hour}:{now.minute:02d}"  # 형식에 맞게 날짜 및 시간 출력
    worksheet_log.update(range_name='a2', values=[[formatted_time]])

    
def update_bugisa_checked():
    print("******** update_bugisa_checked *******")
    filename_bugisa = f'combined_bugisa_{datetime.now().strftime("%Y%m%d")}'
    spreadsheet_id_bugisa = baikukFunction.get_spreadsheet_id_by_name_with_retries(
        baikukFunction.get_spreadsheet_id_by_name,
        var.drive_data_folder_id,
        filename_bugisa
    )
    spreadsheet_bugisa = baikukFunction.open_spreadsheet_with_retries(
        client,
        spreadsheet_id_bugisa
    )
    worksheet_bugisa = spreadsheet_bugisa.get_worksheet(0)
    data = worksheet_bugisa.get_all_values()
    df_bugisa = pd.DataFrame(data[1:], columns=data[0])  # 첫 번째 행을 컬럼 이름으로 사용  
    df_bugisa = df_bugisa[df_bugisa['거래유형'].str.contains('월세', na=False)] #포함한 행만 남기기
    df_bugisa = df_bugisa[df_bugisa['거래완료 여부'].str.contains('진행중', na=False)] #포함한 행만 남기기
    df_bugisa = df_bugisa[df_bugisa['대분류 1차'].str.contains('상가', na=False)] #포함한 행만 남기기
    
    # 1차 단순화
    desired_columns = ['매물번호', '담당자명', '매물명', '지상,지하 구분', '해당층', '전체층', '보증금(만원)', '월세(만원)', '권리금(만원)', 
                        '전용면적 (평)', '상세정보', '계약면적(㎡)', '공급면적(㎡)']
    df_bugisa = df_bugisa[desired_columns]
    # "링크" 열 생성: 매물번호를 포함한 URL 저장
    df_bugisa['링크'] = df_bugisa['매물번호'].apply(lambda x: f"https://baikuk.com/item/view/{x}")

    ##### 이제부터 부기사에 잘못된거 체크
    ###### 부기사 기본정보 체크
    df_bugisa['층_체크'] = df_bugisa['해당층'].apply(lambda x: '층 오류' if str(x).strip() == '-' else None)
    df_bugisa['보증금_체크'] = df_bugisa['보증금(만원)'].apply(lambda x: '보증금 오류' if str(x).strip() == '-' else None)
    df_bugisa['월세_체크'] = df_bugisa['월세(만원)'].apply(lambda x: '월세 오류' if str(x).strip() == '-' else None)
    df_bugisa['면적_체크'] = df_bugisa['전용면적 (평)'].apply(lambda x: '면적 오류' if str(x).strip() == '-' else None)
    df_bugisa['계약면적_체크'] = df_bugisa.apply(
        lambda row: (
            ('계약면적 있음' if str(row['계약면적(㎡)']).strip() != '-' else '') + 
            ('\n' if str(row['계약면적(㎡)']).strip() != '-' and str(row['공급면적(㎡)']).strip() != '-' else '') +
            ('공급면적 있음' if str(row['공급면적(㎡)']).strip() != '-' else '')
        ).strip(),
        axis=1
    )
    df_bugisa['전체층_체크'] = df_bugisa['전체층'].apply(lambda x: '전체층 오류' if str(x).strip() == '-' else None)

    ######### 상세정보 체크
    df_bugisa['매물번호_상세정보'] = df_bugisa['상세정보'].apply(baikukFunction.extract_baikuk_number)
    df_bugisa['상세정보_매물번호_체크'] = df_bugisa.apply(
        lambda row: '매물번호 오표기' if row['매물번호_상세정보'] != row['매물번호'] else None, axis=1
    )
    
    ###### 상세정보에서 추출
    df_bugisa.loc[:, '상세정보_보증금'] = df_bugisa['상세정보'].apply(baikukFunction.convert_deposit)
    df_bugisa.loc[:, '상세정보_월세'] = df_bugisa['상세정보'].apply(baikukFunction.extract_and_convert)
    df_bugisa.loc[:, '상세정보_면적'] = df_bugisa['상세정보'].apply(baikukFunction.extract_area).fillna('')

    # 수치형으로 변환할 열들을 명시
    numeric_columns = ['보증금(만원)', '월세(만원)', '전용면적 (평)',
                       '상세정보_보증금', '상세정보_월세', '상세정보_면적']

    # 각 열에 대해 수치형으로 변환, 변환 불가 값은 0으로 설정
    for col in numeric_columns:
        df_bugisa[col] = df_bugisa[col].astype(str).str.replace(',', '')  # 콤마 제거
        df_bugisa[col] = pd.to_numeric(df_bugisa[col], errors='coerce').fillna(0)

    df_bugisa['상세정보_보증금_체크'] = df_bugisa.apply(
        lambda row: '보증금 오표기' if row['상세정보_보증금'] != row['보증금(만원)'] else None, axis=1
    )
    df_bugisa['상세정보_월세_체크'] = df_bugisa.apply(
        lambda row: '월세 오표기' if row['상세정보_월세'] != row['월세(만원)'] else None, axis=1
    )
    df_bugisa['상세정보_면적_체크'] = df_bugisa.apply(
        lambda row: '면적 오표기' if abs(row['상세정보_면적'] - row['전용면적 (평)']) >3 else None, axis=1
    )
    # '권리금(만원)' 값이 '-'이고, '상세정보'에 '무권리'가 포함되지 않으면 '무권리 누락' 저장
    df_bugisa['상세정보_권리금_체크'] = df_bugisa.apply(
        lambda row: '무권리 누락' if row['권리금(만원)'] == '-' and '무권리' not in str(row['상세정보']) else None, axis=1
    )
    df_bugisa = df_bugisa.fillna('-').replace('', '-') # 빈셀은 '-' 입력

    ############# 열 선택하고 행 정렬    
    desired_columns = ['매물번호', '링크', '담당자명', '매물명', '보증금_체크', '월세_체크', '면적_체크', '계약면적_체크', '층_체크', '전체층_체크',
                        '상세정보_매물번호_체크', '상세정보_보증금_체크', '상세정보_월세_체크', '상세정보_권리금_체크', '상세정보_면적_체크']
    df_bugisa = df_bugisa[desired_columns]
    # 정렬 기준 열을 뒤에서부터 순서대로 내림차순으로 설정
    sort_columns = [
        '상세정보_면적_체크', '상세정보_권리금_체크', '상세정보_월세_체크', '상세정보_보증금_체크',
        '상세정보_매물번호_체크', '전체층_체크', '층_체크', '계약면적_체크', '면적_체크', '월세_체크', '보증금_체크'
    ]

    # DataFrame 정렬
    df_bugisa = df_bugisa.sort_values(by=sort_columns, ascending=False)
    
    ### 열이름 세팅
    desired_columns = ['매물번호', '링크', '담당자명', '매물명', '보증금', '월세', '면적', '계약면적', '층', '전체층',
                        '내용_매물번호', '내용_보증금', '내용_월세', '내용_권리금', '내용_면적']
    df_bugisa.columns = desired_columns
    
    ######## 저장
    # ------ [광고시트]
    baikukFunction.save_dataframe_to_sheet(var.ad_sheet_key2, df_bugisa, "부기사")

    ####### 백업
    filename_bugisa_check = f'부기사_체크_{datetime.now().strftime("%Y%m%d")}'
    spreadsheet_bugisa_check = baikukFunction.create_backup_spreadsheet(filename_bugisa_check)
    baikukFunction.save_dataframe_to_sheet(spreadsheet_bugisa_check.id, df_bugisa,"기본시트") # 스프레드시트에 저장


def update_bugisa_count():
    from datetime import datetime
    import pandas as pd

    print("----------- 통계시트에 부기사매물시트 업데이트 -----------")

    # 1. 부기사 원본 파일 열기
    filename_bugisa_check = f'combined_bugisa_{datetime.now().strftime("%Y%m%d")}'
    spreadsheet_id_bugisa_check = baikukFunction.get_spreadsheet_id_by_name_with_retries(
        baikukFunction.get_spreadsheet_id_by_name,
        var.drive_data_folder_id,
        filename_bugisa_check
    )
    spreadsheet_bugisa_check = baikukFunction.open_spreadsheet_with_retries(client, spreadsheet_id_bugisa_check)
    worksheet_bugisa_check = spreadsheet_bugisa_check.get_worksheet(0)
    data_bugisa = worksheet_bugisa_check.get_all_values()
    df_bugisa = pd.DataFrame(data_bugisa[1:], columns=data_bugisa[0])
    df_bugisa = df_bugisa[df_bugisa['거래유형'].str.contains('월세', na=False)] #포함한 행만 남기기
    df_bugisa = df_bugisa[df_bugisa['거래완료 여부'].str.contains('진행중', na=False)] #포함한 행만 남기기
    df_bugisa = df_bugisa[df_bugisa['대분류 1차'].str.contains('상가', na=False)] #포함한 행만 남기기

    # 2. 통계 시트 열기
    spreadsheet_statistics = baikukFunction.open_spreadsheet_with_retries(client, var.statistics)
    worksheet_statistics = spreadsheet_statistics.worksheet('부기사매물')
    data_statistics = worksheet_statistics.get_all_values()
    df_statistics = pd.DataFrame(data_statistics[1:], columns=data_statistics[0])

    # 3. 날짜 포맷 설정
    today_str = f"{datetime.now().year}. {datetime.now().month}. {datetime.now().day}"

    # 4. 담당자 리스트
    담당자리스트 = ['백은혜', '이승윤', '조인호', '유명근', '김덕상', '김동현', '한제선', '김혜진', '김영완']

    # 5. '날짜' 컬럼이 없다면 생성
    if '날짜' not in df_statistics.columns:
        df_statistics.insert(0, '날짜', '')

    # 6. 누락된 담당자 열 추가
    for name in 담당자리스트:
        if name not in df_statistics.columns:
            df_statistics[name] = 0

    # 7. 오늘 날짜 행 찾거나 새로 추가
    if today_str in df_statistics['날짜'].values:
        row_index = df_statistics.index[df_statistics['날짜'] == today_str][0]
    else:
        new_row = {col: 0 for col in df_statistics.columns}
        new_row['날짜'] = today_str
        df_statistics = pd.concat([df_statistics, pd.DataFrame([new_row])], ignore_index=True)
        row_index = df_statistics.index[-1]

    # 8. 각 담당자별 매물 수 세고 넣기
    if '담당자명' in df_bugisa.columns:
        for name in 담당자리스트:
            count = df_bugisa['담당자명'].str.contains(name, na=False).sum()
            df_statistics.at[row_index, name] = int(count)
    else:
        print("⚠️ '담당자명' 컬럼이 df_bugisa에 없습니다. 건너뜁니다.")

    # ✅ 9. 일산_전체, 파주_전체 개수 추가
    if '구/군' in df_bugisa.columns:
        ilSanCount = df_bugisa['구/군'].str.contains('일산', na=False).sum()
        pajuCount = df_bugisa['구/군'].str.contains('파주', na=False).sum()
    else:
        ilSanCount = 0
        pajuCount = 0
        print("⚠️ '구/군' 컬럼이 df_bugisa에 없습니다. '일산_전체', '파주_전체'는 0으로 입력됩니다.")

    # 필요한 열이 없다면 생성
    for col_name in ['일산_전체', '파주_전체']:
        if col_name not in df_statistics.columns:
            df_statistics[col_name] = 0

    df_statistics.at[row_index, '일산_전체'] = int(ilSanCount)
    df_statistics.at[row_index, '파주_전체'] = int(pajuCount)

    # 10. 데이터 타입 변환 (JSON 오류 방지)
    df_statistics = df_statistics.astype(object).where(pd.notnull(df_statistics), None)

    # 11. 저장
    baikukFunction.save_dataframe_to_sheet(var.statistics, df_statistics, '부기사매물')

# pip install chardet
def detect_encoding(file_path):
    with open(file_path, 'rb') as f:
        raw_data = f.read(2048)  # 앞부분만 읽어서 감지
    return chardet.detect(raw_data)['encoding']

# pip install xlrd==1.2.0
# pip install html5lib
def update_work_log():
    today_str = datetime.now().strftime("%m%d")
    filename = f"업무일지목록-{today_str}.xls"
    file_path = os.path.join(var.down_path, filename)

    if not os.path.exists(file_path):
        print(f"❌ 파일이 존재하지 않습니다: {file_path}")
        return None

    # ✅ 인코딩 자동 감지
    encoding = detect_encoding(file_path)
    print(f"📦 감지된 인코딩: {encoding}")
    
    try:
        tables = pd.read_html(file_path, encoding=encoding)
        df_work_log = tables[0]

        # ✅ 열 이름이 전부 숫자인 경우: 첫 번째 행을 헤더로 설정
        if all(isinstance(col, int) for col in df_work_log.columns):
            df_work_log.columns = df_work_log.iloc[0]
            df_work_log = df_work_log.drop(index=0).reset_index(drop=True)

        df_work_log.fillna('', inplace=True)
        print(f"✅ HTML 테이블로 로드 완료: {df_work_log.shape}")
    except Exception as e:
        print(f"❌ read_html 실패: {e}")
        return None
    
    df_work_log.drop(columns=['주소'], inplace=True, errors='ignore')
    df_work_log['타입'] = df_work_log['타입'].apply(
        lambda x: '입력' if any(keyword in str(x) for keyword in ['전화', '미팅', '기타']) else x
    )

    # 🔁 열 이름 매핑
    column_mapping = {
        '매물번호': 'listing_id',
        '담당자': 'agent_name',
        '타입': 'type',
        '내용': 'contents',
        '등록일': 'Registration_date'
    }
    df_work_log.rename(columns=column_mapping, inplace=True)
    
    if 'No' in df_work_log.columns:
        df_work_log.drop(columns=['No'], inplace=True)


    # 🚀 Supabase 업로드
    baikukFunction.update_supabase(df_work_log, var.SUPABASE_URL, var.SUPABASE_TABLE_WORK_LOG)

def update_cog_sheet(): # 부기사에서 데이터 다운로드, # bugisa_list 데이터를 가져온 후 변환
    print("*******************************************")
    print("*****부기사 데이터 supabase에 업데이트******")
    print("*******************************************")
    down_bugisa(var.bugisa_id, var.bugisa_pw)
    sum_bugisa()  # sum_bugisa 함수는 엑셀 파일을 병합해서 리스트 반환

    rinal_bugisa_df = bugisa_for_sheet()  # bugisa_conv 함수로 리스트 처리
    update_bugisa(rinal_bugisa_df)

    set_baikukdb.update_bugisa_sheet_to_supabase()

    update_bugisa_checked()
    update_bugisa_count()

    update_work_log() # 업무일지 supabase에 업로드


# 메인 함수
def main():
    baikukFunction.retry_function(update_cog_sheet)

if __name__ == '__main__':
    main()