from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import chromedriver_autoinstaller
from random_user_agent.user_agent import UserAgent
from random_user_agent.params import SoftwareName, OperatingSystem
import pyautogui
from datetime import datetime, timedelta
import gspread
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from oauth2client.service_account import ServiceAccountCredentials
import pandas as pd
from gspread_dataframe import get_as_dataframe
from gspread_dataframe import set_with_dataframe
import signal
import numpy as np
import var
import baikukFunction
from gspread.exceptions import APIError
from collections import Counter
import requests
import re
import json
from tqdm import tqdm  # 진행률 표시용 (선택)
from supabase import create_client

supabase_client = create_client(var.SUPABASE_URL, var.SUPABASE_API_KEY)

HEADERS = {
    "apikey": var.SUPABASE_API_KEY,
    "Authorization": f"Bearer {var.SUPABASE_API_KEY}",
    "Content-Type": "application/json",
    "Prefer": "return=minimal"
}


# 초기 입력값: 날짜형식
today_Ymd = datetime.today().strftime('%Y%m%d')
today_Ymd2 = datetime.today().strftime('%Y-%m-%d')
today_ymd = datetime.today().strftime('%Y%m%d')
today_Y_m_d = datetime.today().strftime('%Y_%m_%d')

# Google API 인증 설정
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name(var.json_site, scope)
client = gspread.authorize(creds)

# 기본 설정
USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36')
API_BASE_URL = 'https://new.land.naver.com'

# OAuth 2.0 인증 파일 경로 설정 (구글드라이브 관련)
scopes = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive'
]
credentials = Credentials.from_service_account_file(f'{var.json_site}', scopes=scopes)

# Google Sheets 및 Drive API 초기화
gc = gspread.authorize(credentials)
drive_service = build('drive', 'v3', credentials=credentials)

# 크롬 드라이버 자동 설치
chromedriver_autoinstaller.install()

# 크롬 옵션 설정
chrome_options = Options()
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=http://homesdid.co.kr/mmc/")
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=https://baikuk.com/") 
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=http://homesdid.co.kr/mmc/") 

pyautogui.FAILSAFE = False

# 프로그램 종료 플래그
should_terminate = False

# SIGINT 핸들러 정의
def signal_handler(sig, frame):
    global should_terminate
    print('Ctrl+C 입력됨. 프로그램을 중지하고 데이터를 저장합니다...')
    should_terminate = True

# SIGINT 핸들러 등록
signal.signal(signal.SIGINT, signal_handler)

# 물건번호호출로그 6개월치 가져와서 하나의 데이터프레임으로 반환
def load_recent_6_months_maemullog():
    print("📦 최근 6개월 '물건번호로그' 데이터를 불러옵니다...")

    current = datetime.now()
    current_month = current.month
    current_year = current.year

    # 최근 6개월의 (연도, 월) 리스트 생성
    recent_months = []
    for i in range(6):
        month = current_month - i
        year = current_year
        if month <= 0:
            month += 12
            year -= 1
        recent_months.append((year, str(month)))  # 시트 이름은 문자열

    df_list = []

    for year, month in recent_months:
        file_name = f"물건번호로그_{year}"
        try:
            # 🔹 파일 ID 가져오기
            spreadsheet_id = baikukFunction.get_spreadsheet_id_with_retries(
                baikukFunction.get_spreadsheet_id_by_name,
                var.maemulLog_data_folder_id,
                file_name
            )

            # 🔹 스프레드시트 열기
            spreadsheet = baikukFunction.open_spreadsheet_with_retries(client, spreadsheet_id)

            # 🔹 월 시트 열기 (ex. '1', '2', ..., '12')
            worksheet = spreadsheet.worksheet(month)
            data = worksheet.get_all_values()
            df = pd.DataFrame(data[1:], columns=data[0])
            df_list.append(df)
            print(f"✅ '{file_name}' 시트 '{month}' 로드 완료")
        except Exception as e:
            print(f"⚠️ '{file_name}' 시트 '{month}' 로드 실패: {e}")

    if not df_list:
        raise ValueError("최근 6개월 시트를 불러오지 못했습니다.")

    # 병합
    df_maemullog = pd.concat(df_list, ignore_index=True)

    # 필요한 열만 필터링 (안전하게)
    expected_columns = ['매물번호', '현재날짜', '입력자']
    df_maemullog = df_maemullog[[col for col in expected_columns if col in df_maemullog.columns]]

    return df_maemullog

def get_agent_name_only(s) -> str:
    """
    JS 함수 동작을 파이썬으로 구현:
    1) 괄호()와 대괄호[] 안의 내용을 제거
    2) 구분자(· / - |) 이후 부분 제거
    3) 흔한 직책 접미사(팀장, 부장, …, 공인중개사) 제거
    """
    if not s:
        return ""

    # 1) 괄호/대괄호 내용 제거
    no_paren = re.sub(r"\([^)]*\)|\[[^\]]*\]", "", str(s))

    # 2) 구분자 기준 앞부분만 취함
    cut_after_sep = re.split(r"[·/\-\|]", no_paren)[0]

    # 3) 직책 접미사 제거
    result = re.sub(
        r"\s+(팀장|부장|실장|대리|과장|매니저|대표|소장|사원|본부장|지점장|부지점장|중개사|공인중개사)\s*$",
        "",
        cut_after_sep
    ).strip()

    return result

def bugisa_for_supabase():
    print("********* bugisa_for_supabase ***********")
    # 현재 날짜와 하루 전 날짜 설정
    current_date = datetime.now()

    # 파일명 생성
    filename_bugisa = f'combined_bugisa_{current_date.strftime("%Y%m%d")}'

    # 스프레드시트 ID 가져오기 시도
    spreadsheet_id_bugisa = baikukFunction.get_spreadsheet_id_with_retries(
        baikukFunction.get_spreadsheet_id_by_name,
        var.drive_data_folder_id,
        filename_bugisa
    )
    spreadsheet_bugisa = baikukFunction.open_spreadsheet_with_retries(
        client,
        spreadsheet_id_bugisa
    )
    worksheet_bugisa = spreadsheet_bugisa.get_worksheet(0)
    data = worksheet_bugisa.get_all_values()
    bugisa_df = pd.DataFrame(data[1:], columns=data[0])  # 첫 번째 행을 컬럼 이름으로 사용
    # 수치형으로 변환할 열들을 명시
    numeric_columns = ['전용면적 (평)', '보증금(만원)', '월세(만원)', '권리금(만원)', '매매가(만원)', 
                       '총월세 보증금(만원)', '총월세', '전용면적 (㎡)']

    # 각 열에 대해 수치형으로 변환, 변환 불가 값은 0으로 설정
    for col in numeric_columns:
        bugisa_df[col] = bugisa_df[col].astype(str).str.replace(',', '')  # 콤마 제거
        bugisa_df[col] = pd.to_numeric(bugisa_df[col], errors='coerce').fillna(0)

    # '지상,지하 구분' 값에 불필요한 공백을 제거하고 대소문자를 통일하여 비교
    bugisa_df['해당층'] = bugisa_df.apply(
        lambda row: f"-{row['해당층']}" if row['지상,지하 구분'].strip().lower() == '지하' and not str(row['해당층']).startswith('-') else row['해당층'], 
        axis=1
    )
    
    bugisa_df['시/도'] = bugisa_df['시/도'].str.replace(r'서울시\s*', '서울', regex=True)
    bugisa_df['시/도'] = bugisa_df['시/도'].str.replace(r'^서울', '서울시', regex=True)
    bugisa_df['시/도'] = bugisa_df['시/도'].str.replace(r'경기도\s*', '경기', regex=True)
    bugisa_df['시/도'] = bugisa_df['시/도'].str.replace(r'^경기', '경기도', regex=True)
    bugisa_df['구/군'] = bugisa_df['구/군'].str.replace(r'고양시\s*', '고양', regex=True)
    bugisa_df['구/군'] = bugisa_df['구/군'].str.replace(r'^고양', '고양시 ', regex=True)

    # .loc[]를 사용하여 값을 수정
    bugisa_df.loc[:, '링크'] = 'https://baikuk.com/item/view/' + bugisa_df['매물번호'].astype(str)
    # 숫자 또는 숫자-숫자가 포함된 앞부분을 추출 (입력값을 문자열로 변환하여 오류 방지)
    bugisa_df['상세주소'] = bugisa_df['상세주소'].astype(str)
    bugisa_df['추출된주소'] = bugisa_df['상세주소'].str.extract(r'(^.*?\s*(\d+-\d+|\d+))', expand=False)[0]
    # NaN 값이 발생하면 기존 값 유지
    bugisa_df['상세주소'] = bugisa_df['추출된주소'].combine_first(bugisa_df['상세주소'])
    bugisa_df['상세주소'] = bugisa_df['상세주소'].apply(lambda x: None if str(x).strip() in ['', '-', 'null', 'None'] else x)
    # 임시 컬럼 삭제
    bugisa_df.drop(columns=['추출된주소'], inplace=True)

    bugisa_df.loc[:, '지번주소'] = bugisa_df['시/도'] + ' ' + bugisa_df['구/군'] + ' ' + bugisa_df['동/읍/면'] + ' ' + bugisa_df['상세주소']

    # 0으로 나누는 상황에서 값을 0으로 표시
    bugisa_df['평당임대료'] = np.where(bugisa_df['전용면적 (평)'] == 0, 0, bugisa_df['월세(만원)'] / bugisa_df['전용면적 (평)'])
    bugisa_df['평당매매가'] = np.where(bugisa_df['전용면적 (평)'] == 0, 0, bugisa_df['매매가(만원)'] / bugisa_df['전용면적 (평)'])
    
    # 수익률 계산 (0으로 나누는 경우 수익률은 0으로 처리)
    bugisa_df['수익률'] = np.where((bugisa_df['매매가(만원)'] - bugisa_df['총월세 보증금(만원)']) == 0, 0, 
                                    (bugisa_df['총월세'] * 12) / (bugisa_df['매매가(만원)'] - bugisa_df['총월세 보증금(만원)']))

    # 결측값을 0으로 채우기
    bugisa_df = bugisa_df.fillna(0)

    # '건물명'이 비어있거나 '-'이면 '동명' 값을 저장
    bugisa_df['건물명'] = bugisa_df['건물명'].replace({'-': None, '': None, '0': None, 0: None}).fillna(bugisa_df['동명'])

    # '업종' 열 생성
    bugisa_df['업종'] = bugisa_df['상세정보'].apply(baikukFunction.extract_business_type)

    # 적용
    bugisa_df['특징'] = bugisa_df['상세정보'].apply(baikukFunction.extract_features)

    # 추천횟수
    df_maemullog = load_recent_6_months_maemullog()
    # 매물번호별 추천 횟수 계산 (df_maemullog 기준)
    recommend_counts = df_maemullog['매물번호'].value_counts()

    # bugisa_df에 추천 횟수 매핑
    bugisa_df['추천'] = bugisa_df['매물번호'].astype(str).map(recommend_counts).fillna(0).astype(int)

    print(f'백억장부 원본 시트에 키 추가중...')    
    # 필요한 열이 모두 존재하는지 확인
    required_columns = ['지번주소', '해당층', '전용면적 (㎡)', '보증금(만원)', '월세(만원)']
    for col in required_columns:
        if col not in bugisa_df.columns:
            raise ValueError(f"데이터프레임에 '{col}' 열이 없습니다.")

    # 전용면적이 숫자인지 확인하고, 문자열인 경우 float로 변환
    bugisa_df['전용면적 (㎡)'] = pd.to_numeric(bugisa_df['전용면적 (㎡)'], errors='coerce')

    # '거래완료 여부'에 '진행중'이라는 단어가 포함되어 있으면 '공개', 아니면 '비공개'
    bugisa_df['공개'] = bugisa_df['거래완료 여부'].apply(
        lambda x: '공개' if '진행중' in str(x) else '비공개'
    )
    # '상가종류' 열 생성 (기본값: 일반상가)
    bugisa_df['상가종류'] = '일반상가'
    bugisa_df['방'] = '건축물현황도상 방없음'
    # '상세정보'에서 '용도' 추출
    bugisa_df['건축물용도'] = bugisa_df['상세정보'].apply(baikukFunction.extract_building_usage)
    # 화장실 내외부 추출
    bugisa_df['화장실'] = bugisa_df['상세정보'].apply(baikukFunction.extract_restroom_location)
    
    # 해당층, 총층 오류값 0으로
    for col in ['해당층', '전체층']:
        bugisa_df[col] = pd.to_numeric(bugisa_df[col], errors='coerce').fillna(0).astype(int)

    bugisa_df['위도'] = 0.0
    bugisa_df['경도'] = 0.0

    bugisa_df = bugisa_df.drop_duplicates(subset='매물번호', keep='first') # 매물번호 중복 제거

    # 선택한 열만 유지
    columns_to_select = [
        '매물번호',              # listing_id
        '링크',                 # 링크는 supabase에 없다면 제거해도 됨
        '담당자명',              # agent_name
        '거래완료 여부',          # transaction_status
        '공개',                 # is_public
        '상가종류',              # store_type
        '대분류 1차',            # category
        '거래유형',              # deal_type
        '지번주소',              # full_address 또는 full_address 조합
        '건물명',               # building_name
        '호수정보',              # unit_info
        '해당층',               # floor
        '전체층',               # total_floors
        '매물명',               # listing_title
        '전용면적 (평)',         # area_py
        '전용면적 (㎡)',         # area_m2
        '보증금(만원)',          # deposit_price
        '월세(만원)',            # monthly_rent
        '평당임대료',            # rent_per_py
        '권리금(만원)',          # premium_price
        '매매가(만원)',          # sale_price
        '평당매매가',            # sale_per_py
        '총월세 보증금(만원)',     # total_deposit
        '총월세',               # total_rent
        '수익률',               # roi
        '업종',                # store_type_detail
        '특징',                # features
        '추천',                # recommend_count
        '비밀메모',             # private_note
        '건축물용도',            # building_usage
        '화장실',            # restroom
        '위도', '경도',
        '등록일',
        '수정일',
        '시/도',
        '구/군',
        '동/읍/면',
        '상세주소',
        '공급면적(㎡)',
        '공급면적(평)',
        '대지면적(㎡)',
        '대지면적(평)',
        '건축면적(㎡)',
        '건축면적(평)',
        '연면적(㎡)',
        '연면적(평)',
        '토지면적(㎡)',
        '토지면적(평)',
        '방향',
        '주차',
        '제목',
        '상세정보',
        '사용승인일'
    ]
   
    df = bugisa_df[columns_to_select]

    rename_columns = {
        '매물번호': 'listing_id',
        '링크': 'listing_url',
        '담당자명': 'agent_name',
        '거래완료 여부': 'transaction_status',
        '공개': 'is_public',
        '상가종류': 'store_type',
        '대분류 1차': 'category',
        '거래유형': 'deal_type',
        '지번주소': 'full_address',
        '건물명': 'building_name',
        '호수정보': 'unit_info',
        '해당층': 'floor',
        '전체층': 'total_floors',
        '매물명': 'listing_title',
        '전용면적 (평)': 'area_py',
        '전용면적 (㎡)': 'area_m2',
        '보증금(만원)': 'deposit_price',
        '월세(만원)': 'monthly_rent',
        '평당임대료': 'rent_per_py',
        '권리금(만원)': 'premium_price',
        '매매가(만원)': 'sale_price',
        '평당매매가': 'sale_per_py',
        '총월세 보증금(만원)': 'total_deposit',
        '총월세': 'total_rent',
        '수익률': 'roi',
        '업종': 'store_type_detail',
        '특징': 'features',
        '추천': 'recommend_count',
        '비밀메모': 'private_note',
        '건축물용도': 'building_usage',
        '화장실': 'restroom',
        '위도' : 'lat',
        '경도' : 'lng',
        '등록일': 'created_at',
        '수정일': 'updated_at',
        '시/도': 'province',
        '구/군': 'city',
        '동/읍/면': 'district',
        '상세주소' : 'detail_address',
        '공급면적(㎡)': 'supply_area_m2',
        '공급면적(평)': 'supply_area_py',
        '대지면적(㎡)': 'land_area_m2',
        '대지면적(평)': 'land_area_py',
        '건축면적(㎡)': 'building_area_m2',
        '건축면적(평)': 'building_area_py',
        '연면적(㎡)': 'total_floor_area_m2',
        '연면적(평)': 'total_floor_area_py',
        '토지면적(㎡)': 'site_area_m2',
        '토지면적(평)': 'site_area_py',
        '방향': 'direction',
        '주차': 'parking',
        '제목': 'title',
        '상세정보': 'description',
        '사용승인일': 'approved_date'
    }

    # 영어 열 이름으로 변경
    df = df.rename(columns=rename_columns)

    # 방향 데이터 간소화 (예: 북동향 (주된 출입구 기준) --> 북동향)
    df["direction"] = df["direction"].str.replace(r"\s*\(.*$", "", regex=True).str.strip()

    # 날짜 + 시간 컬럼 (ISO8601 형식)
    timestamp_columns = ['created_at', 'updated_at']
    for col in timestamp_columns:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce').dt.strftime('%Y-%m-%dT%H:%M:%S')

    # 날짜만 필요한 컬럼
    date_columns = ['approved_date']
    for col in date_columns:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce').dt.strftime('%Y-%m-%d')

    # 🔧 텍스트 컬럼 기본값 채우기 (빈 값 → '-')
    text_columns_to_default_dash = ['entrance', 'ad_status', 'customer_data', 'ad_type']

    for col in text_columns_to_default_dash:
        if col in df.columns:
            df[col] = df[col].fillna('-').astype(str).str.strip()
            df[col] = df[col].replace('', '-')  # 빈 문자열도 '-'로 대체
    
    
    # 위도 경도 넣어야하는 부분. supabase에서 비교해서 넣자
    supabase_lat_lng_df = baikukFunction.fetch_all_rows_from_supabase_table(supabase_client, var.SUPABASE_TABLE_only_lat_lng)
    # 주소 비교를 위해 공백 제거 등 정규화 (선택사항)
    df['full_address'] = df['full_address'].astype(str).str.strip()
    supabase_lat_lng_df['full_address'] = supabase_lat_lng_df['full_address'].astype(str).str.strip()

    # 병합 수행 (full_address 기준)
    df = pd.merge(
        df,
        supabase_lat_lng_df[['full_address', 'lat', 'lng']],
        on='full_address',
        how='left',
        suffixes=('', '_supabase')
    )
    # df.to_excel("부기사_데이터_merged.xlsx", index=False)

    # lat, lng 값이 있으면 채워주기
    df['lat'] = df['lat_supabase'].fillna(df['lat'])
    df['lng'] = df['lng_supabase'].fillna(df['lng'])

    # 보조 컬럼 제거
    df.drop(columns=['lat_supabase', 'lng_supabase'], inplace=True)
    
    # 🔧 Supabase 스키마에 맞게 타입 정제
    numeric_cols = [
        'listing_id', 'floor', 'total_floors',
        'parking',  # ✅ 추가됨
        'sale_price', 'deposit_price', 'monthly_rent', 'premium_price',
        'total_deposit', 'total_rent',
        'area_m2', 'area_py',
        'supply_area_m2', 'supply_area_py',
        'land_area_m2', 'land_area_py',
        'building_area_m2', 'building_area_py',
        'total_floor_area_m2', 'total_floor_area_py',
        'site_area_m2', 'site_area_py',
        'recommend_count', 'sale_per_py', 'rent_per_py', 'roi',
        'lat', 'lng'
    ]
    # Supabase에서 bigint 타입으로 정의된 필드 → 반드시 int 처리
    int_cols = [
        'listing_id', 'floor', 'total_floors', 'recommend_count', 'parking'
    ]

    # 나머지 numeric_cols 중 float 처리할 필드
    float_cols = list(set(numeric_cols) - set(int_cols))

    # int 처리
    for col in int_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0).astype(int)

    # float 처리
    for col in float_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0).astype(float)
    df.drop(columns=['building_name'], inplace=True)

    # get_agent_name_only(s) 가 이미 정의돼 있다고 가정
    df['agent_name'] = df['agent_name'].map(lambda s: get_agent_name_only(s) if pd.notna(s) else s)

    # 누락된 열 추가
    missing_columns = [
        'entrance', 'ad_status', 'customer_data', 'ad_type', 'carrier',
        'buildingownername', 'ownerphonenumber', 'ownergender', 'owner_address',
        'store_category', 'room_count'
    ]

    for col in missing_columns:
        if col not in df.columns:
            df[col] = '-'  # 열이 없으면 새로 만들고 '-'로 채움
        else:
            df[col] = df[col].fillna('-').replace('', '-')  # 빈 값도 '-'로 대체

    
    df = df.astype(str).applymap(lambda x: '-' if str(x).strip().lower() in ['', 'nan', 'none', 'null'] else x)

    numeric_cols = [
        'listing_id', 'floor', 'total_floors', 'sale_price', 'deposit_price', 'monthly_rent',
        'premium_price', 'total_deposit', 'total_rent', 'area_m2', 'area_py',
        'supply_area_m2', 'supply_area_py', 'land_area_m2', 'land_area_py',
        'building_area_m2', 'building_area_py', 'total_floor_area_m2',
        'total_floor_area_py', 'site_area_m2', 'site_area_py', 'parking',
        'lat', 'lng', 'sale_per_py', 'roi', 'rent_per_py', 'recommend_count'
    ]

    # 숫자형 컬럼 처리: '-', '', 'null', 'None', NaN → 0
    for col in numeric_cols:
        if col in df.columns:
            df[col] = (
                df[col]
                .replace(['-', '', 'null', 'None'], np.nan)  # 문자열 null 값들 처리
                .replace(r'^\s*$', np.nan, regex=True)        # 공백 문자열도 NaN 처리
            )
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)

    # 1. timestamptz → "YYYY-MM-DDTHH:MM:SS"
    for col in ['created_at', 'updated_at']:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')
            df[col] = df[col].apply(
                lambda x: x.strftime('%Y-%m-%dT%H:%M:%S') if pd.notnull(x) else '1990-04-25T00:00:00'
            )

    # 2. date → "YYYY-MM-DD"
    for col in ['approved_date']:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')
            df[col] = df[col].apply(
                lambda x: x.date().isoformat() if pd.notnull(x) else '1990-04-25'
            )

    # df.to_excel("부기사_데이터.xlsx", index=False)

    return df

def update_bugisa_sheet_to_supabase(): # 부기사에서 데이터 다운로드, # bugisa_list 데이터를 가져온 후 변환
    print("**********************************")
    print("*****supabase 데이터 업데이트******")
    print("**********************************")

    bugisa_df = bugisa_for_supabase()    
    # NaN → None 처리 (JSON 직렬화 호환성 확보)
    bugisa_df = bugisa_df.replace({np.nan: None})
    records = bugisa_df.to_dict(orient="records")
    try:
        json_str = json.dumps(records)
        print("✅ JSON 직렬화 성공 — Supabase 업로드 가능")
    except Exception as e:
        print("🚨 JSON 직렬화 실패!", e)
        print("⚠️ Supabase 업로드 중단됨")
        return  # 직렬화 실패 시 중단
    
    baikukFunction.update_supabase(bugisa_df, var.SUPABASE_URL, var.SUPABASE_TABLE_BAIKUKDBTEST)

# 메인 함수
def main():
    baikukFunction.retry_function(update_bugisa_sheet_to_supabase)

if __name__ == '__main__':
    main()