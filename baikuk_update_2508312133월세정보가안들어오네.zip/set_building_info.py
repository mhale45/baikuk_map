from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import chromedriver_autoinstaller
from random_user_agent.user_agent import UserAgent
from random_user_agent.params import SoftwareName, OperatingSystem
import pyautogui
from datetime import datetime, timedelta
import gspread
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from oauth2client.service_account import ServiceAccountCredentials
import pandas as pd
from gspread_dataframe import get_as_dataframe
from gspread_dataframe import set_with_dataframe
import signal
import numpy as np
import var
import baikukFunction
from gspread.exceptions import APIError
from collections import Counter
import requests
import re
import json
from tqdm import tqdm  # 진행률 표시용 (선택)
from supabase import create_client

supabase_client = create_client(var.SUPABASE_URL, var.SUPABASE_API_KEY)

HEADERS = {
    "apikey": var.SUPABASE_API_KEY,
    "Authorization": f"Bearer {var.SUPABASE_API_KEY}",
    "Content-Type": "application/json",
    "Prefer": "return=minimal"
}


# 초기 입력값: 날짜형식
today_Ymd = datetime.today().strftime('%Y%m%d')
today_Ymd2 = datetime.today().strftime('%Y-%m-%d')
today_ymd = datetime.today().strftime('%Y%m%d')
today_Y_m_d = datetime.today().strftime('%Y_%m_%d')

# Google API 인증 설정
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name(var.json_site, scope)
client = gspread.authorize(creds)

# 기본 설정
USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36')
API_BASE_URL = 'https://new.land.naver.com'

# OAuth 2.0 인증 파일 경로 설정 (구글드라이브 관련)
scopes = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive'
]
credentials = Credentials.from_service_account_file(f'{var.json_site}', scopes=scopes)

# Google Sheets 및 Drive API 초기화
gc = gspread.authorize(credentials)
drive_service = build('drive', 'v3', credentials=credentials)

# 크롬 드라이버 자동 설치
chromedriver_autoinstaller.install()

# 크롬 옵션 설정
chrome_options = Options()
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=http://homesdid.co.kr/mmc/")
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=https://baikuk.com/") 
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=http://homesdid.co.kr/mmc/") 

pyautogui.FAILSAFE = False

# 프로그램 종료 플래그
should_terminate = False

# SIGINT 핸들러 정의
def signal_handler(sig, frame):
    global should_terminate
    print('Ctrl+C 입력됨. 프로그램을 중지하고 데이터를 저장합니다...')
    should_terminate = True

# SIGINT 핸들러 등록
signal.signal(signal.SIGINT, signal_handler)

# 물건번호호출로그 6개월치 가져와서 하나의 데이터프레임으로 반환
def load_recent_6_months_maemullog():
    print("📦 최근 6개월 '물건번호로그' 데이터를 불러옵니다...")

    current = datetime.now()
    current_month = current.month
    current_year = current.year

    # 최근 6개월의 (연도, 월) 리스트 생성
    recent_months = []
    for i in range(6):
        month = current_month - i
        year = current_year
        if month <= 0:
            month += 12
            year -= 1
        recent_months.append((year, str(month)))  # 시트 이름은 문자열

    df_list = []

    for year, month in recent_months:
        file_name = f"물건번호로그_{year}"
        try:
            # 🔹 파일 ID 가져오기
            spreadsheet_id = baikukFunction.get_spreadsheet_id_with_retries(
                baikukFunction.get_spreadsheet_id_by_name,
                var.maemulLog_data_folder_id,
                file_name
            )

            # 🔹 스프레드시트 열기
            spreadsheet = baikukFunction.open_spreadsheet_with_retries(client, spreadsheet_id)

            # 🔹 월 시트 열기 (ex. '1', '2', ..., '12')
            worksheet = spreadsheet.worksheet(month)
            data = worksheet.get_all_values()
            df = pd.DataFrame(data[1:], columns=data[0])
            df_list.append(df)
            print(f"✅ '{file_name}' 시트 '{month}' 로드 완료")
        except Exception as e:
            print(f"⚠️ '{file_name}' 시트 '{month}' 로드 실패: {e}")

    if not df_list:
        raise ValueError("최근 6개월 시트를 불러오지 못했습니다.")

    # 병합
    df_maemullog = pd.concat(df_list, ignore_index=True)

    # 필요한 열만 필터링 (안전하게)
    expected_columns = ['매물번호', '현재날짜', '입력자']
    df_maemullog = df_maemullog[[col for col in expected_columns if col in df_maemullog.columns]]

    return df_maemullog

def building_name_info():    
    # 건물정보 열기
    spreadsheet_building_info = baikukFunction.open_spreadsheet_with_retries(client, var.store_info)
    worksheet_building_info = spreadsheet_building_info.get_worksheet(0)
    data_building_info = worksheet_building_info.get_all_values()
    df_building_info = pd.DataFrame(data_building_info[1:], columns=data_building_info[0])

    unique_df_building_info = df_building_info.drop_duplicates(subset='주소')
    unique_df_building_info = unique_df_building_info[['주소', '건물명']]
    unique_df_building_info.rename(columns={'주소': 'full_address', '건물명': 'building_name'}, inplace=True)

    # 널/공백 처리 (안전하게)
    unique_df_building_info['full_address'] = (
        unique_df_building_info['full_address']
        .fillna('')
        .astype(str)
        .str.strip()
    )

    # ✅ 문자열 치환 규칙 적용
    unique_df_building_info['full_address'] = (
        unique_df_building_info['full_address']
        .str.replace(r'^경기(?=\s)', '경기도', regex=True)   # "경기 " → "경기도"
        .str.replace(r'^서울(?=\s)', '서울시', regex=True)   # "서울 " → "서울시"
        .str.replace(r'고양(?!시)', '고양시 ', regex=True)  # "고양" (뒤에 '시' 없을 때만) → "고양시 "
        .str.replace(r'\s+', ' ', regex=True)              # 공백 여러 개 → 한 칸
        .str.strip()
    )

    return unique_df_building_info

def management_office_bugisa():
    # 현재 날짜와 하루 전 날짜 설정
    current_date = datetime.now()

    # 파일명 생성
    filename_bugisa = f'combined_bugisa_{current_date.strftime("%Y%m%d")}'

    # 스프레드시트 ID 가져오기 시도
    spreadsheet_id_bugisa = baikukFunction.get_spreadsheet_id_with_retries(
        baikukFunction.get_spreadsheet_id_by_name,
        var.drive_data_folder_id,
        filename_bugisa
    )
    spreadsheet_bugisa = baikukFunction.open_spreadsheet_with_retries(
        client,
        spreadsheet_id_bugisa
    )
    worksheet_bugisa = spreadsheet_bugisa.get_worksheet(0)
    data = worksheet_bugisa.get_all_values()
    bugisa_df = pd.DataFrame(data[1:], columns=data[0])  # 첫 번째 행을 컬럼 이름으로 사용

    # '매물명'에 '관리소' 포함된 행만 남기기
    bugisa_df = bugisa_df[bugisa_df['매물명'].str.contains('관리소', na=False)]

    bugisa_df = bugisa_df[['매물명', '비밀메모', '시/도', '구/군', '동/읍/면', '상세주소']].copy()

    # 2) 널/공백 안전 처리
    for col in ['시/도', '구/군']:
        bugisa_df[col] = bugisa_df[col].fillna('').astype(str).str.strip()

    # 3) '시/도': '경기' → '경기도' (정확히 일치할 때만)
    bugisa_df.loc[bugisa_df['시/도'] == '경기', '시/도'] = '경기도'
    bugisa_df.loc[bugisa_df['시/도'] == '서울', '시/도'] = '서울시'
    bugisa_df['구/군'] = bugisa_df['구/군'].str.replace(r'^고양(?!시)', '고양시 ', regex=True)
    bugisa_df['상세주소'] = bugisa_df['상세주소'].str.replace(r"\(.*\)", "", regex=True).str.strip()

    for col in ['시/도', '구/군', '동/읍/면', '상세주소']:
        bugisa_df[col] = bugisa_df[col].fillna('').astype(str).str.strip()

    bugisa_df['전체주소'] = (
        bugisa_df['시/도'] + ' ' +
        bugisa_df['구/군'] + ' ' +
        bugisa_df['동/읍/면'] + ' ' +
        bugisa_df['상세주소']
    ).str.strip()

    # '전체주소' 기준으로 중복 제거 → 첫 번째 행만 남김
    bugisa_df = bugisa_df.drop_duplicates(subset=['전체주소'], keep='first')

    # '비밀메모'와 '전체주소' 열만 남기기
    bugisa_df = bugisa_df[['비밀메모', '전체주소']]

    bugisa_df = bugisa_df.rename(columns={
        '비밀메모': 'building_note',
        '전체주소': 'full_address'
    })

    # ✅ 엑셀 저장
    # date_str = current_date.strftime("%Y%m%d")
    # excel_file = f"bugisa_df_{date_str}.xlsx"
    # bugisa_df.to_excel(excel_file, index=False, engine="openpyxl")
    # print(f"📦 엑셀 저장 완료: {excel_file}")

    return bugisa_df

def update_bugisa_sheet_to_supabase(): # 부기사에서 데이터 다운로드, # bugisa_list 데이터를 가져온 후 변환
    print("********************************")
    print("*****supabase 데이터 업데이트******")
    print("********************************")

    # bugisa_and_only_lat_lng()
    building_info_df = management_office_bugisa()
    building_name_df = building_name_info()
    building_df = building_name_df.merge(
        building_info_df[['full_address', 'building_note']],
        on='full_address',
        how='left'
    )
    building_df = building_df.dropna(subset=['full_address'])
    building_df = building_df[building_df['full_address'].str.strip().astype(bool)]
    # full_address 기준으로 중복 제거 (하나만 남기기)
    building_df = building_df.drop_duplicates(subset=['full_address'], keep='last')
    building_df['building_info'] = (
        building_df['building_note']
        .fillna('')
        .astype(str)
        .str.strip()
        .replace(['', 'null', 'None', 'nan'], '-', regex=False)
    )

    building_df['full_address'] = (
        building_df['full_address']
            .str.replace('경기도 ', '경기 ', regex=False)
            .str.replace('고양시 ', '고양', regex=False)
    )

    building_df['full_address'] = (
        building_df['full_address']
            .str.replace('경기', '경기도', regex=False)
            .str.replace('고양', '고양시 ', regex=False)
    )

    building_df = building_df[['full_address', 'building_name', 'building_note']]
    
    
    baikukFunction.upsert_supabase(building_df, var.SUPABASE_URL, var.SUPABASE_TABLE_BUILDING_INFO, var.SUPABASE_API_SURVIVCE_KEY,  conflict_key='full_address')
    
# 메인 함수
def main():
    baikukFunction.retry_function(update_bugisa_sheet_to_supabase)

if __name__ == '__main__':
    main()