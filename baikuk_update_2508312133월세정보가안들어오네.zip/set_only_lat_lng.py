from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import chromedriver_autoinstaller
from random_user_agent.user_agent import UserAgent
from random_user_agent.params import SoftwareName, OperatingSystem
import pyautogui
from datetime import datetime, timedelta
import gspread
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from oauth2client.service_account import ServiceAccountCredentials
import pandas as pd
from gspread_dataframe import get_as_dataframe
from gspread_dataframe import set_with_dataframe
import signal
import numpy as np
import var
import baikukFunction
from gspread.exceptions import APIError
from collections import Counter
import requests
import json
from tqdm import tqdm  # 진행률 표시용 (선택)
from supabase import create_client
import time

supabase = create_client(var.SUPABASE_URL, var.SUPABASE_API_KEY)


HEADERS = {
    "apikey": var.SUPABASE_API_KEY,
    "Authorization": f"Bearer {var.SUPABASE_API_KEY}",
    "Content-Type": "application/json",
    "Prefer": "return=minimal"
}


# 초기 입력값: 날짜형식
today_Ymd = datetime.today().strftime('%Y%m%d')
today_Ymd2 = datetime.today().strftime('%Y-%m-%d')
today_ymd = datetime.today().strftime('%Y%m%d')
today_Y_m_d = datetime.today().strftime('%Y_%m_%d')

# Google API 인증 설정
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name(var.json_site, scope)
client = gspread.authorize(creds)

# 기본 설정
USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36')
API_BASE_URL = 'https://new.land.naver.com'

# OAuth 2.0 인증 파일 경로 설정 (구글드라이브 관련)
scopes = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive'
]
credentials = Credentials.from_service_account_file(f'{var.json_site}', scopes=scopes)

# Google Sheets 및 Drive API 초기화
gc = gspread.authorize(credentials)
drive_service = build('drive', 'v3', credentials=credentials)

# 크롬 드라이버 자동 설치
chromedriver_autoinstaller.install()

# 크롬 옵션 설정
chrome_options = Options()
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=http://homesdid.co.kr/mmc/")
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=https://baikuk.com/") 
chrome_options.add_argument("--unsafely-treat-insecure-origin-as-secure=http://homesdid.co.kr/mmc/") 

pyautogui.FAILSAFE = False

# 프로그램 종료 플래그
should_terminate = False

# SIGINT 핸들러 정의
def signal_handler(sig, frame):
    global should_terminate
    print('Ctrl+C 입력됨. 프로그램을 중지하고 데이터를 저장합니다...')
    should_terminate = True

# SIGINT 핸들러 등록
signal.signal(signal.SIGINT, signal_handler)

def fetch_table_as_dataframe(table_name):
    """
    Supabase 테이블 데이터를 DataFrame으로 불러오는 함수
    """
    try:
        response = supabase.table(table_name).select("*").execute()

        if response.data:
            df = pd.DataFrame(response.data)
            return df
        else:
            print(f"⚠️ 테이블 '{table_name}'에 데이터가 없습니다.")
            return pd.DataFrame()
    except Exception as e:
        print(f"❌ '{table_name}' 테이블을 불러오는 중 오류 발생: {e}")
        return pd.DataFrame()

def update_bugisa_sheet_to_supabase():
    print("********************************")
    print("*****supabase 데이터 업데이트******")
    print("********************************")

    df = pd.read_excel("baikukdbtest.xlsx")
    df_lat_lng = df[['full_address', 'lat', 'lng']].copy()

    df_only_lat_lng = fetch_table_as_dataframe("only_lat_lng")

    # 중복 제거 (full_address 기준)
    df_lat_lng = df_lat_lng.drop_duplicates(subset='full_address')
    df_only_lat_lng = df_only_lat_lng.drop_duplicates(subset='full_address')

    # 기존 Supabase 데이터로 먼저 덮어쓰기
    df_only_lat_lng_sub = df_only_lat_lng[['full_address', 'lat', 'lng']].set_index('full_address')
    df_lat_lng.set_index('full_address', inplace=True)
    df_lat_lng.update(df_only_lat_lng_sub, overwrite=True)
    df_lat_lng.reset_index(inplace=True)
 
    # Kakao API로 좌표 보완
    target_rows = df_lat_lng[
        (df_lat_lng['lat'].isna()) |
        (df_lat_lng['lng'].isna()) |
        ((df_lat_lng['lat'] == 0.0) & (df_lat_lng['lng'] == 0.0))
    ]
    print(f"📍 좌표 업데이트 대상 행 수: {len(target_rows)}")

    for i, row in tqdm(target_rows.iterrows(), total=len(target_rows)):
        address = row['full_address']
        lat, lng = baikukFunction.get_lat_lng(address, var.KAKAO_API_KEY2)
        if lat and lng:
            df_lat_lng.loc[df_lat_lng['full_address'] == address, 'lat'] = round(lat, 6)
            df_lat_lng.loc[df_lat_lng['full_address'] == address, 'lng'] = round(lng, 6)
        else:
            print(f"❗️좌표 업데이트 실패: {address}")
        time.sleep(0.3)

    # ✅ 누락된 주소 추가 (Supabase에는 있지만 엑셀에는 없는 주소)
    missing_addresses = set(df_only_lat_lng['full_address']) - set(df_lat_lng['full_address'])
    missing_rows = df_only_lat_lng[df_only_lat_lng['full_address'].isin(missing_addresses)]
    df_lat_lng = pd.concat([df_lat_lng, missing_rows])

    # 📌 Supabase에 only_lat_lng 테이블 업데이트
    baikukFunction.update_supabase(df_lat_lng, var.SUPABASE_URL, var.SUPABASE_TABLE_only_lat_lng)

    # ✅ 원본 df에 최신 lat/lng 덮어쓰기
    df.set_index('full_address', inplace=True)
    df_lat_lng.set_index('full_address', inplace=True)
    df.update(df_lat_lng[['lat', 'lng']], overwrite=True)
    df.reset_index(inplace=True)

    # 기본값 채우기
    DEFAULT_LAT = round(37.761573, 6)
    DEFAULT_LNG = round(126.669886, 6)
    df.loc[df['lat'] == 0, 'lat'] = DEFAULT_LAT
    df.loc[df['lng'] == 0, 'lng'] = DEFAULT_LNG

    # 📌 Supabase에 원본 테이블 (baikukdbtest) 업데이트
    baikukFunction.update_supabase(df, var.SUPABASE_URL, var.SUPABASE_TABLE_BAIKUKDBTEST)



# 메인 함수
def main():
    baikukFunction.retry_function(update_bugisa_sheet_to_supabase)

if __name__ == '__main__':
    main()